.class Lkz/qqqschulz/strike2d/MainActivity$21;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkz/qqqschulz/strike2d/MainActivity;->U()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lkz/qqqschulz/strike2d/MainActivity;


# direct methods
.method constructor <init>(Lkz/qqqschulz/strike2d/MainActivity;)V
    .registers 2

    .line 5210
    iput-object p1, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method a()I
    .registers 9

    .line 5212
    iget-object v0, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Fu:Ljava/net/Socket;

    const/4 v1, -0x1

    if-eqz v0, :cond_d9

    iget-object v0, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Fu:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->isConnected()Z

    move-result v0

    if-nez v0, :cond_13

    goto/16 :goto_d9

    .line 5218
    :cond_13
    :try_start_13
    iget-object v0, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Fw:Ljava/io/InputStream;

    iget-object v2, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->Fx:[B

    invoke-virtual {v0, v2}, Ljava/io/InputStream;->read([B)I

    move-result v0

    .line 5219
    iget-object v2, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-boolean v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->wF:Z

    const/4 v3, 0x0

    if-eqz v2, :cond_2a

    iget-object v2, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput v3, v2, Lkz/qqqschulz/strike2d/MainActivity;->wG:I

    :cond_2a
    if-nez v0, :cond_2d

    goto :goto_77

    :cond_2d
    if-ne v0, v1, :cond_35

    .line 5222
    iget-object v0, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->X()V

    return v1

    .line 5225
    :cond_35
    iget-object v2, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->FH:[B

    if-nez v2, :cond_4a

    .line 5226
    iget-object v2, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v4, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v4, v4, Lkz/qqqschulz/strike2d/MainActivity;->Fx:[B

    invoke-virtual {v4}, [B->clone()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [B

    iput-object v4, v2, Lkz/qqqschulz/strike2d/MainActivity;->FH:[B

    goto :goto_6a

    .line 5228
    :cond_4a
    iget-object v2, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->FH:[B

    .line 5229
    iget-object v4, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    array-length v5, v2

    add-int/2addr v5, v0

    new-array v5, v5, [B

    iput-object v5, v4, Lkz/qqqschulz/strike2d/MainActivity;->FH:[B

    .line 5230
    iget-object v4, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v4, v4, Lkz/qqqschulz/strike2d/MainActivity;->FH:[B

    array-length v5, v2

    invoke-static {v2, v3, v4, v3, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 5231
    iget-object v4, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v4, v4, Lkz/qqqschulz/strike2d/MainActivity;->Fx:[B

    iget-object v5, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v5, v5, Lkz/qqqschulz/strike2d/MainActivity;->FH:[B

    array-length v2, v2

    invoke-static {v4, v3, v5, v2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 5233
    :goto_6a
    iget-object v2, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v4, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v4, v4, Lkz/qqqschulz/strike2d/MainActivity;->FI:I

    add-int/2addr v4, v0

    iput v4, v2, Lkz/qqqschulz/strike2d/MainActivity;->FI:I
    :try_end_73
    .catch Ljava/net/SocketTimeoutException; {:try_start_13 .. :try_end_73} :catch_d4
    .catch Ljava/io/IOException; {:try_start_13 .. :try_end_73} :catch_cf

    const/16 v2, 0x544

    if-ge v0, v2, :cond_13

    .line 5242
    :goto_77
    iget-object v0, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->FH:[B

    const/4 v1, 0x0

    if-eqz v0, :cond_c8

    iget-object v0, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->FI:I

    if-gtz v0, :cond_85

    goto :goto_c8

    :cond_85
    const/4 v0, 0x0

    const/4 v2, 0x0

    .line 5249
    :goto_87
    iget-object v4, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v4, v4, Lkz/qqqschulz/strike2d/MainActivity;->FI:I

    if-ge v0, v4, :cond_c7

    .line 5250
    iget-object v4, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v4, v4, Lkz/qqqschulz/strike2d/MainActivity;->FH:[B

    if-eqz v4, :cond_c4

    iget-object v4, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v4, v4, Lkz/qqqschulz/strike2d/MainActivity;->FH:[B

    aget-byte v4, v4, v0

    if-nez v4, :cond_c4

    .line 5251
    new-instance v4, Ljava/lang/String;

    iget-object v5, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v5, v5, Lkz/qqqschulz/strike2d/MainActivity;->FH:[B

    sub-int v6, v0, v2

    const-string v7, "UTF-8"

    invoke-static {v7}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v7

    invoke-direct {v4, v5, v2, v6, v7}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    .line 5253
    :try_start_ac
    invoke-virtual {p0, v4}, Lkz/qqqschulz/strike2d/MainActivity$21;->a(Ljava/lang/String;)V
    :try_end_af
    .catch Ljava/lang/Exception; {:try_start_ac .. :try_end_af} :catch_b0

    goto :goto_b4

    :catch_b0
    move-exception v2

    .line 5255
    invoke-virtual {v2}, Ljava/lang/Exception;->printStackTrace()V

    :goto_b4
    add-int/lit8 v2, v0, 0x1

    .line 5258
    iget-object v4, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v4, v4, Lkz/qqqschulz/strike2d/MainActivity;->FI:I

    add-int/lit8 v4, v4, -0x1

    if-ne v0, v4, :cond_c4

    .line 5259
    iget-object v4, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-object v1, v4, Lkz/qqqschulz/strike2d/MainActivity;->FH:[B

    .line 5260
    iput v3, v4, Lkz/qqqschulz/strike2d/MainActivity;->FI:I

    :cond_c4
    add-int/lit8 v0, v0, 0x1

    goto :goto_87

    :cond_c7
    return v3

    .line 5243
    :cond_c8
    :goto_c8
    iget-object v0, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->FH:[B

    .line 5244
    iput v3, v0, Lkz/qqqschulz/strike2d/MainActivity;->FI:I

    return v3

    :catch_cf
    move-exception v0

    .line 5239
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    return v1

    :catch_d4
    move-exception v0

    .line 5236
    invoke-virtual {v0}, Ljava/net/SocketTimeoutException;->printStackTrace()V

    return v1

    :cond_d9
    :goto_d9
    return v1
.end method

.method a(Ljava/lang/String;)V
    .registers 24

    move-object/from16 v8, p0

    move-object/from16 v0, p1

    if-eqz v0, :cond_1653

    .line 5268
    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->length()I

    move-result v1

    if-gtz v1, :cond_e

    goto/16 :goto_1653

    .line 5269
    :cond_e
    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->length()I

    move-result v1

    if-gtz v1, :cond_15

    return-void

    .line 5273
    :cond_15
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x0

    const/4 v1, 0x0

    :cond_1c
    const/16 v10, 0x8

    .line 5275
    invoke-virtual {v0, v10, v1}, Ljava/lang/String;->indexOf(II)I

    move-result v2

    const/4 v11, -0x1

    if-ne v2, v11, :cond_2d

    .line 5277
    invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v7, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_36

    .line 5279
    :cond_2d
    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v7, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v2, 0x1

    :goto_36
    if-ne v2, v11, :cond_1c

    .line 5283
    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1652

    .line 5285
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_msglist_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-wide/16 v12, 0x0

    const/4 v14, 0x2

    const/4 v15, 0x1

    if-eqz v0, :cond_1cd

    .line 5286
    invoke-interface {v7, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 5287
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-boolean v15, v1, Lkz/qqqschulz/strike2d/MainActivity;->CZ:Z

    .line 5288
    iget v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->pV:I

    if-ltz v1, :cond_1652

    .line 5289
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->CO:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-lt v1, v2, :cond_6e

    goto/16 :goto_1652

    .line 5292
    :cond_6e
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->CO:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    if-eq v0, v2, :cond_80

    goto/16 :goto_1652

    .line 5293
    :cond_80
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 5294
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 5295
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 5296
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 5300
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->CR:Ljava/util/HashMap;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-virtual {v2, v10}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_b5

    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->CR:Ljava/util/HashMap;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-virtual {v2, v10}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v16

    goto :goto_b7

    :cond_b5
    move-wide/from16 v16, v12

    .line 5301
    :goto_b7
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v2

    sub-int/2addr v2, v15

    move-wide/from16 v18, v12

    :goto_be
    if-le v2, v15, :cond_16d

    add-int/lit8 v10, v2, -0x3

    if-ge v10, v14, :cond_c6

    goto/16 :goto_16d

    .line 5303
    :cond_c6
    invoke-interface {v7, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    invoke-static {v10}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v18

    add-int/lit8 v10, v2, -0x2

    .line 5304
    invoke-interface {v7, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    invoke-static {v10}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10

    .line 5305
    iget-object v11, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-wide v14, v11, Lkz/qqqschulz/strike2d/MainActivity;->CX:J

    cmp-long v11, v14, v12

    if-eqz v11, :cond_ec

    iget-object v11, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v11, v11, Lkz/qqqschulz/strike2d/MainActivity;->BN:I

    if-ne v10, v11, :cond_ec

    goto/16 :goto_166

    .line 5306
    :cond_ec
    iget-object v11, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v11, v11, Lkz/qqqschulz/strike2d/MainActivity;->BN:I

    if-ne v10, v11, :cond_f7

    .line 5307
    iget-object v11, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v11, v11, Lkz/qqqschulz/strike2d/MainActivity;->qa:Ljava/lang/String;

    goto :goto_101

    .line 5309
    :cond_f7
    iget-object v11, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v11, v11, Lkz/qqqschulz/strike2d/MainActivity;->CN:Ljava/util/List;

    invoke-interface {v11, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    .line 5311
    :goto_101
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-virtual {v3, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5312
    invoke-virtual {v4, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v10, v2, -0x1

    .line 5313
    invoke-interface {v7, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v5, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5314
    iget-object v10, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-virtual {v10, v11}, Lkz/qqqschulz/strike2d/MainActivity;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v6, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    cmp-long v10, v18, v16

    if-nez v10, :cond_166

    cmp-long v10, v16, v12

    if-eqz v10, :cond_166

    add-int/lit8 v10, v2, -0x7

    const/4 v11, 0x2

    if-lt v10, v11, :cond_166

    .line 5316
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-virtual {v3, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const-string v9, ""

    .line 5317
    invoke-virtual {v4, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5318
    div-int/lit8 v9, v2, 0x4

    const/4 v10, 0x1

    sub-int/2addr v9, v10

    .line 5319
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v9}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v11, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v11, v11, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v14, 0x7f060156

    invoke-virtual {v11, v14}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v5, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const-string v10, ""

    .line 5320
    invoke-virtual {v6, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_166
    :goto_166
    add-int/lit8 v2, v2, -0x4

    const/4 v11, -0x1

    const/4 v14, 0x2

    const/4 v15, 0x1

    goto/16 :goto_be

    .line 5324
    :cond_16d
    :goto_16d
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-wide v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->CX:J

    move-wide/from16 v12, v18

    cmp-long v7, v12, v1

    if-lez v7, :cond_189

    .line 5325
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-wide v12, v1, Lkz/qqqschulz/strike2d/MainActivity;->CX:J

    .line 5326
    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->CR:Ljava/util/HashMap;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v1, v0, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1b5

    .line 5328
    :cond_189
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->CO:Ljava/util/List;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v1

    const/4 v2, -0x1

    if-eq v1, v2, :cond_1b5

    .line 5330
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->CP:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    .line 5331
    iget-object v7, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v7, v7, Lkz/qqqschulz/strike2d/MainActivity;->CR:Ljava/util/HashMap;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v7, v0, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 5334
    :cond_1b5
    :goto_1b5
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1bd

    goto/16 :goto_1652

    .line 5335
    :cond_1bd
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v10, Lkz/qqqschulz/strike2d/MainActivity$21$1;

    move-object v1, v10

    move-object/from16 v2, p0

    move v7, v9

    invoke-direct/range {v1 .. v7}, Lkz/qqqschulz/strike2d/MainActivity$21$1;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;I)V

    invoke-virtual {v0, v10}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto/16 :goto_1652

    .line 5345
    :cond_1cd
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_mymaps_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_217

    .line 5346
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x1

    .line 5347
    :goto_1e1
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_1fb

    .line 5348
    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    if-eqz v2, :cond_1f8

    .line 5349
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_1f8

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1f8
    add-int/lit8 v1, v1, 0x1

    goto :goto_1e1

    .line 5351
    :cond_1fb
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1652

    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->Js:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1652

    .line 5352
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v2, Lkz/qqqschulz/strike2d/MainActivity$21$10;

    invoke-direct {v2, v8, v0}, Lkz/qqqschulz/strike2d/MainActivity$21$10;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;Ljava/util/ArrayList;)V

    invoke-virtual {v1, v2}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto/16 :goto_1652

    .line 5368
    :cond_217
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_mapstop_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v11, 0x3

    if-eqz v0, :cond_233

    .line 5369
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->JE:I

    if-ne v0, v11, :cond_22e

    goto/16 :goto_1652

    .line 5370
    :cond_22e
    invoke-virtual {v8, v7}, Lkz/qqqschulz/strike2d/MainActivity$21;->a(Ljava/util/List;)V

    goto/16 :goto_1652

    .line 5373
    :cond_233
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_mapfind_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_24e

    .line 5374
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->JE:I

    if-eq v0, v11, :cond_249

    goto/16 :goto_1652

    .line 5375
    :cond_249
    invoke-virtual {v8, v7}, Lkz/qqqschulz/strike2d/MainActivity$21;->a(Ljava/util/List;)V

    goto/16 :goto_1652

    .line 5378
    :cond_24e
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_grmsglist_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3cd

    const/4 v0, 0x1

    .line 5379
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    .line 5380
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-boolean v0, v2, Lkz/qqqschulz/strike2d/MainActivity;->CZ:Z

    .line 5381
    iget v0, v2, Lkz/qqqschulz/strike2d/MainActivity;->Dx:I

    if-eq v1, v0, :cond_271

    goto/16 :goto_1652

    .line 5383
    :cond_271
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 5384
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 5385
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 5386
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 5390
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Do:Ljava/util/HashMap;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2a6

    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Do:Ljava/util/HashMap;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v10

    goto :goto_2a7

    :cond_2a6
    move-wide v10, v12

    .line 5391
    :goto_2a7
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x1

    sub-int/2addr v0, v2

    move-wide v14, v12

    :goto_2ae
    if-le v0, v2, :cond_36a

    add-int/lit8 v2, v0, -0x4

    const/4 v12, 0x2

    if-ge v2, v12, :cond_2bb

    move/from16 v20, v1

    move/from16 v18, v9

    goto/16 :goto_36e

    .line 5393
    :cond_2bb
    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v14

    add-int/lit8 v2, v0, -0x3

    .line 5394
    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    add-int/lit8 v12, v0, -0x2

    .line 5395
    invoke-interface {v7, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    .line 5396
    iget-object v13, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    move/from16 v18, v9

    add-int/lit8 v9, v0, -0x1

    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v13, v9}, Lkz/qqqschulz/strike2d/MainActivity;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 5397
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    move-object/from16 v19, v7

    .line 5398
    iget-object v7, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    move/from16 v21, v0

    move/from16 v20, v1

    iget-wide v0, v7, Lkz/qqqschulz/strike2d/MainActivity;->CX:J

    const-wide/16 v16, 0x0

    cmp-long v7, v0, v16

    if-eqz v7, :cond_306

    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->BN:I

    if-ne v2, v0, :cond_306

    goto :goto_35d

    .line 5399
    :cond_306
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5400
    invoke-virtual {v4, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5401
    invoke-virtual {v5, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5402
    invoke-virtual {v6, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    cmp-long v0, v14, v10

    if-nez v0, :cond_35d

    const-wide/16 v0, 0x0

    cmp-long v2, v10, v0

    if-eqz v2, :cond_35d

    add-int/lit8 v0, v21, -0x9

    const/4 v1, 0x2

    if-lt v0, v1, :cond_35d

    .line 5404
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const-string v0, ""

    .line 5405
    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5406
    div-int/lit8 v0, v21, 0x5

    const/4 v1, 0x1

    add-int/lit8 v9, v0, -0x1

    .line 5407
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v9}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060156

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const-string v0, ""

    .line 5408
    invoke-virtual {v6, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_35f

    :cond_35d
    :goto_35d
    move/from16 v9, v18

    :goto_35f
    add-int/lit8 v0, v21, -0x5

    move-object/from16 v7, v19

    move/from16 v1, v20

    const/4 v2, 0x1

    const-wide/16 v12, 0x0

    goto/16 :goto_2ae

    :cond_36a
    move/from16 v20, v1

    move/from16 v18, v9

    .line 5412
    :goto_36e
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-wide v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->CX:J

    cmp-long v2, v14, v0

    if-lez v2, :cond_388

    .line 5413
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-wide v14, v0, Lkz/qqqschulz/strike2d/MainActivity;->CX:J

    .line 5414
    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Do:Ljava/util/HashMap;

    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_3b4

    .line 5416
    :cond_388
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Dk:Ljava/util/List;

    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_3b4

    .line 5418
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->Dn:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    .line 5419
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->Do:Ljava/util/HashMap;

    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {v2, v7, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 5422
    :cond_3b4
    :goto_3b4
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_3bc

    goto/16 :goto_1652

    .line 5423
    :cond_3bc
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v9, Lkz/qqqschulz/strike2d/MainActivity$21$11;

    move-object v1, v9

    move-object/from16 v2, p0

    move/from16 v7, v18

    invoke-direct/range {v1 .. v7}, Lkz/qqqschulz/strike2d/MainActivity$21$11;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;I)V

    invoke-virtual {v0, v9}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto/16 :goto_1652

    .line 5433
    :cond_3cd
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_grmsgok_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v12, 0x4

    if-eqz v0, :cond_463

    const/4 v0, 0x1

    .line 5434
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/4 v1, 0x2

    .line 5435
    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    .line 5436
    invoke-interface {v7, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .line 5437
    iget-object v4, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v4, v5}, Lkz/qqqschulz/strike2d/MainActivity;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 5438
    iget-object v5, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v5, v5, Lkz/qqqschulz/strike2d/MainActivity;->Dx:I

    if-eq v0, v5, :cond_40c

    goto/16 :goto_1652

    .line 5439
    :cond_40c
    iget-object v5, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-wide v5, v5, Lkz/qqqschulz/strike2d/MainActivity;->CX:J

    cmp-long v7, v1, v5

    if-lez v7, :cond_425

    .line 5440
    iget-object v5, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-wide v1, v5, Lkz/qqqschulz/strike2d/MainActivity;->CX:J

    .line 5441
    iget-object v5, v5, Lkz/qqqschulz/strike2d/MainActivity;->Do:Ljava/util/HashMap;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v5, v0, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 5443
    :cond_425
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 5444
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 5445
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 5446
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 5447
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->BN:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5448
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->qa:Ljava/lang/String;

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5449
    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5450
    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5451
    iget-object v9, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v10, Lkz/qqqschulz/strike2d/MainActivity$21$12;

    move-object v1, v10

    move-object/from16 v2, p0

    move-object v3, v0

    move-object v4, v5

    move-object v5, v7

    invoke-direct/range {v1 .. v6}, Lkz/qqqschulz/strike2d/MainActivity$21$12;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    invoke-virtual {v9, v10}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto/16 :goto_1652

    .line 5461
    :cond_463
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_msgok_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v13, 0x5

    if-eqz v0, :cond_518

    .line 5462
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->pV:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_1652

    .line 5463
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->CO:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-lt v0, v1, :cond_485

    goto/16 :goto_1652

    :cond_485
    const/4 v1, 0x1

    .line 5464
    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    const/4 v3, 0x2

    .line 5465
    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    .line 5466
    invoke-interface {v7, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    .line 5467
    iget-object v5, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v5, v5, Lkz/qqqschulz/strike2d/MainActivity;->CO:Ljava/util/List;

    invoke-interface {v5, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    if-eq v4, v0, :cond_4b7

    goto/16 :goto_1652

    .line 5468
    :cond_4b7
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-wide v5, v0, Lkz/qqqschulz/strike2d/MainActivity;->CX:J

    cmp-long v0, v1, v5

    if-lez v0, :cond_4d0

    .line 5469
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-wide v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->CX:J

    .line 5470
    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->CR:Ljava/util/HashMap;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, v4, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 5472
    :cond_4d0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 5473
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 5474
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 5475
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 5476
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5477
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->qa:Ljava/lang/String;

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5478
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v1, v2}, Lkz/qqqschulz/strike2d/MainActivity;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5479
    invoke-interface {v7, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5480
    iget-object v7, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v9, Lkz/qqqschulz/strike2d/MainActivity$21$13;

    move-object v1, v9

    move-object/from16 v2, p0

    move-object v3, v0

    invoke-direct/range {v1 .. v6}, Lkz/qqqschulz/strike2d/MainActivity$21$13;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    invoke-virtual {v7, v9}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto/16 :goto_1652

    .line 5490
    :cond_518
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_mapdata_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5ee

    .line 5491
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput v9, v0, Lkz/qqqschulz/strike2d/MainActivity;->wG:I

    const/4 v0, 0x1

    .line 5492
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 5493
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->Jz:Lkz/qqqschulz/strike2d/MainActivity$ag;

    if-eqz v1, :cond_1652

    .line 5494
    iget-boolean v2, v1, Lkz/qqqschulz/strike2d/MainActivity$ag;->b:Z

    if-eqz v2, :cond_1652

    if-eqz v0, :cond_1652

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity$ag;->d:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_547

    goto/16 :goto_1652

    :cond_547
    const/4 v1, 0x2

    .line 5495
    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    .line 5496
    invoke-interface {v7, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    .line 5497
    invoke-interface {v7, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .line 5498
    invoke-interface {v7, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    if-eqz v3, :cond_5e7

    if-eqz v4, :cond_5e7

    .line 5499
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v5

    if-ne v5, v1, :cond_5e7

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v1

    if-eq v1, v2, :cond_579

    goto :goto_5e7

    .line 5504
    :cond_579
    :try_start_579
    new-instance v1, Ljava/io/DataOutputStream;

    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, ".map"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5, v9}, Lkz/qqqschulz/strike2d/MainActivity;->openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 5505
    invoke-static {v3, v9}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v2

    .line 5506
    invoke-virtual {v1, v2}, Ljava/io/DataOutputStream;->write([B)V

    .line 5507
    invoke-virtual {v1}, Ljava/io/DataOutputStream;->close()V

    .line 5508
    new-instance v1, Ljava/io/DataOutputStream;

    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, ".ob"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3, v9}, Lkz/qqqschulz/strike2d/MainActivity;->openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 5509
    invoke-static {v4, v9}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v2

    .line 5510
    invoke-virtual {v1, v2}, Ljava/io/DataOutputStream;->write([B)V

    .line 5511
    invoke-virtual {v1}, Ljava/io/DataOutputStream;->close()V

    .line 5512
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ".map"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity;->wH:Ljava/lang/String;
    :try_end_5da
    .catch Ljava/lang/Exception; {:try_start_579 .. :try_end_5da} :catch_5dc

    goto/16 :goto_1652

    :catch_5dc
    move-exception v0

    .line 5514
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 5515
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->bE()V

    goto/16 :goto_1652

    .line 5500
    :cond_5e7
    :goto_5e7
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->bE()V

    goto/16 :goto_1652

    .line 5519
    :cond_5ee
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_error_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_60c

    .line 5520
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060083

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5523
    :cond_60c
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_nomapfound_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_62a

    .line 5524
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f0600f3

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5527
    :cond_62a
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_accerror_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_648

    .line 5528
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060150

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5531
    :cond_648
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_screrror_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_666

    .line 5532
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060177

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5535
    :cond_666
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_delmapok_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6b2

    .line 5536
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f0600cb

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    const/4 v0, 0x1

    .line 5537
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const/4 v1, 0x0

    .line 5538
    :goto_68a
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->Js:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1652

    .line 5539
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->Js:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lkz/qqqschulz/strike2d/MainActivity$q;

    if-eqz v2, :cond_6af

    .line 5540
    iget-object v3, v2, Lkz/qqqschulz/strike2d/MainActivity$q;->b:Ljava/lang/String;

    if-nez v3, :cond_6a5

    goto :goto_6af

    .line 5541
    :cond_6a5
    iget-object v3, v2, Lkz/qqqschulz/strike2d/MainActivity$q;->b:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_6af

    iput-boolean v9, v2, Lkz/qqqschulz/strike2d/MainActivity$q;->i:Z

    :cond_6af
    :goto_6af
    add-int/lit8 v1, v1, 0x1

    goto :goto_68a

    .line 5545
    :cond_6b2
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_mapupdated_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6fe

    .line 5546
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f0600d4

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    const/4 v0, 0x1

    .line 5547
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 5548
    :goto_6d5
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Js:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v9, v0, :cond_1652

    .line 5549
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Js:Ljava/util/ArrayList;

    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lkz/qqqschulz/strike2d/MainActivity$q;

    if-eqz v0, :cond_6fb

    .line 5550
    iget-object v2, v0, Lkz/qqqschulz/strike2d/MainActivity$q;->b:Ljava/lang/String;

    if-nez v2, :cond_6f0

    goto :goto_6fb

    .line 5551
    :cond_6f0
    iget-object v2, v0, Lkz/qqqschulz/strike2d/MainActivity$q;->b:Ljava/lang/String;

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6fb

    const/4 v2, 0x1

    iput-boolean v2, v0, Lkz/qqqschulz/strike2d/MainActivity$q;->i:Z

    :cond_6fb
    :goto_6fb
    add-int/lit8 v9, v9, 0x1

    goto :goto_6d5

    .line 5555
    :cond_6fe
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_mapsaved_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_74a

    .line 5556
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f0600d5

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    const/4 v0, 0x1

    .line 5557
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 5558
    :goto_721
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Js:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v9, v0, :cond_1652

    .line 5559
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Js:Ljava/util/ArrayList;

    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lkz/qqqschulz/strike2d/MainActivity$q;

    if-eqz v0, :cond_747

    .line 5560
    iget-object v2, v0, Lkz/qqqschulz/strike2d/MainActivity$q;->b:Ljava/lang/String;

    if-nez v2, :cond_73c

    goto :goto_747

    .line 5561
    :cond_73c
    iget-object v2, v0, Lkz/qqqschulz/strike2d/MainActivity$q;->b:Ljava/lang/String;

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_747

    const/4 v2, 0x1

    iput-boolean v2, v0, Lkz/qqqschulz/strike2d/MainActivity$q;->i:Z

    :cond_747
    :goto_747
    add-int/lit8 v9, v9, 0x1

    goto :goto_721

    .line 5565
    :cond_74a
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_mappovt_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_768

    .line 5566
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f06014e

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5569
    :cond_768
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_onemap_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_786

    .line 5570
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f0600ef

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5573
    :cond_786
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_mapname_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7a4

    .line 5574
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060039

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5577
    :cond_7a4
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_nogr_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7c2

    .line 5578
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f0600ec

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5581
    :cond_7c2
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_delparterror_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7e0

    .line 5582
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060172

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5585
    :cond_7e0
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_addpartok_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_88b

    const/4 v0, 0x1

    .line 5586
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 5587
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->Dx:I

    if-eq v0, v1, :cond_801

    goto/16 :goto_1652

    :cond_801
    const/4 v1, 0x2

    .line 5588
    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    .line 5589
    invoke-interface {v7, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    move-object v14, v2

    check-cast v14, Ljava/lang/String;

    .line 5590
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v2, v3}, Lkz/qqqschulz/strike2d/MainActivity;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 5591
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 5592
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 5593
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 5594
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 5595
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5596
    invoke-virtual {v4, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5597
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5598
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5599
    iget-object v15, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v2, Lkz/qqqschulz/strike2d/MainActivity$21$14;

    move-object v1, v2

    move-object v10, v2

    move-object/from16 v2, p0

    invoke-direct/range {v1 .. v6}, Lkz/qqqschulz/strike2d/MainActivity$21$14;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    invoke-virtual {v15, v10}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 5606
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v3, v3, Lkz/qqqschulz/strike2d/MainActivity;->qa:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v3, v3, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v4, 0x7f060005

    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v3, v3, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v4, 0x7f060152

    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "ffffffffffff"

    invoke-virtual {v1, v0, v2, v3}, Lkz/qqqschulz/strike2d/MainActivity;->b(ILjava/lang/String;Ljava/lang/String;)V

    .line 5608
    :cond_88b
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_grpok_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_931

    const/4 v0, 0x1

    .line 5609
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/4 v1, 0x2

    .line 5610
    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    move-object v12, v2

    check-cast v12, Ljava/lang/String;

    .line 5611
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 5612
    new-instance v1, Lkz/qqqschulz/strike2d/MainActivity$m;

    const-wide/16 v13, 0x0

    const/4 v15, 0x1

    move-object v10, v1

    move v11, v0

    invoke-direct/range {v10 .. v15}, Lkz/qqqschulz/strike2d/MainActivity$m;-><init>(ILjava/lang/String;JI)V

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5613
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v1}, Lkz/qqqschulz/strike2d/MainActivity;->t()V

    .line 5614
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 5615
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 5616
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 5617
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 5618
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->BN:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5619
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->qa:Ljava/lang/String;

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const-string v1, "online"

    .line 5620
    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x1

    .line 5621
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5622
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    const/4 v10, 0x2

    iput v10, v2, Lkz/qqqschulz/strike2d/MainActivity;->Dv:I

    .line 5623
    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->eD:[Z

    const/16 v10, 0x56

    aput-boolean v9, v2, v10

    .line 5624
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->eD:[Z

    const/16 v10, 0x57

    aput-boolean v1, v2, v10

    .line 5625
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput v0, v2, Lkz/qqqschulz/strike2d/MainActivity;->Dx:I

    .line 5626
    iput-boolean v9, v2, Lkz/qqqschulz/strike2d/MainActivity;->Dw:Z

    .line 5627
    iput-boolean v1, v2, Lkz/qqqschulz/strike2d/MainActivity;->ft:Z

    .line 5628
    iget-object v0, v2, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v1, 0x7f0600f4

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    .line 5629
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->P()V

    .line 5630
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v9, Lkz/qqqschulz/strike2d/MainActivity$21$15;

    move-object v1, v9

    move-object/from16 v2, p0

    invoke-direct/range {v1 .. v7}, Lkz/qqqschulz/strike2d/MainActivity$21$15;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    invoke-virtual {v0, v9}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto/16 :goto_1652

    .line 5641
    :cond_931
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_grpmax_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_94f

    .line 5642
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060114

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5645
    :cond_94f
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_addfrok_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_96f

    const/4 v0, 0x1

    .line 5646
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 5647
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v1, v0}, Lkz/qqqschulz/strike2d/MainActivity;->z(I)V

    goto/16 :goto_1652

    .line 5650
    :cond_96f
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_addfrmax_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_99d

    .line 5651
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060113

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    const/4 v0, 0x1

    .line 5652
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 5653
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v1, v0}, Lkz/qqqschulz/strike2d/MainActivity;->z(I)V

    goto/16 :goto_1652

    .line 5656
    :cond_99d
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_addfrtwo_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9cb

    .line 5657
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060009

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    const/4 v0, 0x1

    .line 5658
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 5659
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v1, v0}, Lkz/qqqschulz/strike2d/MainActivity;->z(I)V

    goto/16 :goto_1652

    :cond_9cb
    const/4 v0, 0x1

    .line 5662
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v2, "_delfrreqok_"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9eb

    .line 5663
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 5664
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v1, v0}, Lkz/qqqschulz/strike2d/MainActivity;->z(I)V

    goto/16 :goto_1652

    .line 5667
    :cond_9eb
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v2, "_delfrndok_"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a0a

    .line 5668
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 5669
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v1, v0}, Lkz/qqqschulz/strike2d/MainActivity;->x(I)V

    goto/16 :goto_1652

    .line 5672
    :cond_a0a
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v2, "_delpartok_"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a8e

    .line 5673
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/4 v1, 0x2

    .line 5674
    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    .line 5675
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->Dx:I

    if-eq v0, v2, :cond_a35

    goto/16 :goto_1652

    .line 5676
    :cond_a35
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->Dr:Ljava/util/List;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v2

    const-string v3, ""

    const/4 v4, -0x1

    if-eq v2, v4, :cond_a51

    .line 5678
    iget-object v3, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v3, v3, Lkz/qqqschulz/strike2d/MainActivity;->Dq:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Ljava/lang/String;

    .line 5679
    :cond_a51
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v2, v1}, Lkz/qqqschulz/strike2d/MainActivity;->A(I)V

    .line 5680
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v4, v4, Lkz/qqqschulz/strike2d/MainActivity;->qa:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v4, v4, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v5, 0x7f060070

    invoke-virtual {v4, v5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v3, v3, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v4, 0x7f060091

    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "ffffffffffff"

    invoke-virtual {v1, v0, v2, v3}, Lkz/qqqschulz/strike2d/MainActivity;->b(ILjava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5683
    :cond_a8e
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_statpartok_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b3f

    const/4 v0, 0x1

    .line 5684
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    const/4 v0, 0x2

    .line 5685
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 5686
    invoke-interface {v7, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    .line 5687
    iget-object v3, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v3, v3, Lkz/qqqschulz/strike2d/MainActivity;->Dx:I

    if-eq v1, v3, :cond_ac4

    goto/16 :goto_1652

    .line 5688
    :cond_ac4
    iget-object v3, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v3, v3, Lkz/qqqschulz/strike2d/MainActivity;->Dr:Ljava/util/List;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v3, v0}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v3

    const/4 v0, -0x1

    if-ne v3, v0, :cond_ad5

    goto/16 :goto_1652

    .line 5691
    :cond_ad5
    :try_start_ad5
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Ds:Ljava/util/List;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v0, v3, v4}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;
    :try_end_ae0
    .catch Ljava/lang/Exception; {:try_start_ad5 .. :try_end_ae0} :catch_ae1

    goto :goto_ae5

    :catch_ae1
    move-exception v0

    .line 5693
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 5695
    :goto_ae5
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v4, Lkz/qqqschulz/strike2d/MainActivity$21$16;

    invoke-direct {v4, v8}, Lkz/qqqschulz/strike2d/MainActivity$21$16;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;)V

    invoke-virtual {v0, v4}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 5700
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Dq:Ljava/util/List;

    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v2, :cond_b07

    .line 5703
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v3, 0x7f0600f9

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    goto :goto_b12

    .line 5705
    :cond_b07
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v3, 0x7f0600f8

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    .line 5707
    :goto_b12
    iget-object v3, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v5, v5, Lkz/qqqschulz/strike2d/MainActivity;->qa:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v5, v5, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v6, 0x7f060037

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "ffffffffffff"

    invoke-virtual {v3, v1, v0, v2}, Lkz/qqqschulz/strike2d/MainActivity;->b(ILjava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5710
    :cond_b3f
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_delgrpok_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b6d

    const/4 v0, 0x1

    .line 5711
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 5712
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v1, v0}, Lkz/qqqschulz/strike2d/MainActivity;->y(I)V

    .line 5713
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f06014b

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5716
    :cond_b6d
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_leavegrpok_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_bc0

    const/4 v0, 0x1

    .line 5717
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 5718
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v1, v0}, Lkz/qqqschulz/strike2d/MainActivity;->y(I)V

    .line 5719
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v1, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v3, 0x7f060175

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    .line 5720
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v3, v3, Lkz/qqqschulz/strike2d/MainActivity;->qa:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v3, v3, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v4, 0x7f0600b4

    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "ffffffffffff"

    invoke-virtual {v1, v0, v2, v3}, Lkz/qqqschulz/strike2d/MainActivity;->b(ILjava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5723
    :cond_bc0
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_infook_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x6

    const/16 v2, 0x9

    const/4 v3, 0x7

    if-eqz v0, :cond_c56

    .line 5724
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    const/4 v4, 0x1

    invoke-interface {v7, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    iput v4, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cu:I

    .line 5725
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    const/4 v4, 0x2

    invoke-interface {v7, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    iput v4, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cv:I

    .line 5726
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    iput v4, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cw:I

    .line 5727
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    iput v4, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cx:I

    .line 5728
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    iput v4, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cy:I

    .line 5729
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cz:I

    .line 5730
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->CA:I

    .line 5731
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    const/16 v1, 0x8

    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->Ch:Ljava/lang/String;

    .line 5732
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->CC:Ljava/lang/String;

    goto/16 :goto_1652

    .line 5735
    :cond_c56
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v4, "_mapinfook_"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/16 v4, 0xa

    if-eqz v0, :cond_d38

    .line 5736
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    const/4 v5, 0x1

    invoke-interface {v7, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    iput v5, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cr:I

    .line 5737
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    const/4 v5, 0x2

    invoke-interface {v7, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    iput v5, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cl:I

    .line 5738
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    iput-object v5, v0, Lkz/qqqschulz/strike2d/MainActivity;->Ce:Ljava/lang/String;

    .line 5739
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v0, v5}, Lkz/qqqschulz/strike2d/MainActivity;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, v0, Lkz/qqqschulz/strike2d/MainActivity;->Ci:Ljava/lang/String;

    .line 5740
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v0, v5}, Lkz/qqqschulz/strike2d/MainActivity;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cj:Ljava/lang/String;

    .line 5741
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cn:I

    .line 5742
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cm:I

    .line 5743
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    const/16 v1, 0x8

    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->Co:I

    .line 5744
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cp:I

    .line 5745
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cq:I

    .line 5746
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cq:I

    const/16 v1, 0x90

    if-nez v0, :cond_d0a

    .line 5747
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->eD:[Z

    aput-boolean v9, v0, v1

    .line 5748
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->eD:[Z

    const/16 v1, 0x91

    aput-boolean v9, v0, v1

    goto/16 :goto_1652

    .line 5749
    :cond_d0a
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cq:I

    if-lez v0, :cond_d21

    .line 5750
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->eD:[Z

    const/4 v2, 0x1

    aput-boolean v2, v0, v1

    .line 5751
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->eD:[Z

    const/16 v1, 0x91

    aput-boolean v9, v0, v1

    goto/16 :goto_1652

    .line 5752
    :cond_d21
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Cq:I

    if-gez v0, :cond_1652

    .line 5753
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->eD:[Z

    aput-boolean v9, v0, v1

    .line 5754
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->eD:[Z

    const/16 v1, 0x91

    const/4 v2, 0x1

    aput-boolean v2, v0, v1

    goto/16 :goto_1652

    .line 5758
    :cond_d38
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v5, "_reqlist_"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_d8c

    .line 5759
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->s()V

    .line 5760
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 5761
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x1

    .line 5762
    :goto_d56
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v3

    if-ge v2, v3, :cond_d80

    add-int/lit8 v3, v2, 0x1

    .line 5763
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v4

    if-lt v3, v4, :cond_d65

    goto :goto_d80

    .line 5764
    :cond_d65
    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5765
    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x2

    goto :goto_d56

    .line 5767
    :cond_d80
    :goto_d80
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v3, Lkz/qqqschulz/strike2d/MainActivity$21$17;

    invoke-direct {v3, v8, v0, v1}, Lkz/qqqschulz/strike2d/MainActivity$21$17;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    invoke-virtual {v2, v3}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto/16 :goto_1652

    .line 5775
    :cond_d8c
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v5, "_newslist_"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_ddb

    .line 5776
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->q()V

    const/4 v0, 0x1

    .line 5777
    :goto_da0
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_dcf

    add-int/lit8 v1, v0, 0x2

    .line 5778
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v2

    if-lt v1, v2, :cond_daf

    goto :goto_dcf

    .line 5779
    :cond_daf
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    add-int/lit8 v4, v0, 0x1

    invoke-interface {v7, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v2, v3, v4, v1}, Lkz/qqqschulz/strike2d/MainActivity;->a(ILjava/lang/String;Ljava/lang/String;)V

    add-int/lit8 v0, v0, 0x3

    goto :goto_da0

    .line 5781
    :cond_dcf
    :goto_dcf
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v1, Lkz/qqqschulz/strike2d/MainActivity$21$2;

    invoke-direct {v1, v8}, Lkz/qqqschulz/strike2d/MainActivity$21$2;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;)V

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto/16 :goto_1652

    .line 5794
    :cond_ddb
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v5, "_frlist_"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_e46

    .line 5795
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->k()V

    .line 5796
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x1

    .line 5797
    :goto_df4
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_e2a

    add-int/lit8 v2, v1, 0x2

    .line 5798
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v3

    if-lt v2, v3, :cond_e03

    goto :goto_e2a

    .line 5799
    :cond_e03
    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    add-int/lit8 v4, v1, 0x1

    .line 5800
    invoke-interface {v7, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 5801
    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v5

    .line 5802
    new-instance v2, Lkz/qqqschulz/strike2d/MainActivity$f;

    invoke-direct {v2, v3, v4, v5, v6}, Lkz/qqqschulz/strike2d/MainActivity$f;-><init>(ILjava/lang/String;J)V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x3

    goto :goto_df4

    .line 5804
    :cond_e2a
    :goto_e2a
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_e32

    goto/16 :goto_1652

    .line 5805
    :cond_e32
    new-instance v1, Lkz/qqqschulz/strike2d/MainActivity$g;

    invoke-direct {v1}, Lkz/qqqschulz/strike2d/MainActivity$g;-><init>()V

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 5806
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v2, Lkz/qqqschulz/strike2d/MainActivity$21$3;

    invoke-direct {v2, v8, v0}, Lkz/qqqschulz/strike2d/MainActivity$21$3;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;Ljava/util/ArrayList;)V

    invoke-virtual {v1, v2}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto/16 :goto_1652

    .line 5815
    :cond_e46
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v5, "_partlist_"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_ede

    .line 5816
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->t()V

    const/4 v0, 0x1

    .line 5817
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 5818
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->Dx:I

    if-eq v0, v1, :cond_e6c

    goto/16 :goto_1652

    .line 5819
    :cond_e6c
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 5820
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 5821
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 5822
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    const/4 v0, 0x2

    .line 5823
    :goto_e81
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_ecf

    add-int/lit8 v1, v0, 0x3

    .line 5824
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v2

    if-lt v1, v2, :cond_e90

    goto :goto_ecf

    .line 5825
    :cond_e90
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v0, 0x1

    .line 5826
    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5827
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    add-int/lit8 v9, v0, 0x2

    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v2, v9}, Lkz/qqqschulz/strike2d/MainActivity;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5828
    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x4

    goto :goto_e81

    .line 5830
    :cond_ecf
    :goto_ecf
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v7, Lkz/qqqschulz/strike2d/MainActivity$21$4;

    move-object v1, v7

    move-object/from16 v2, p0

    invoke-direct/range {v1 .. v6}, Lkz/qqqschulz/strike2d/MainActivity$21$4;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    invoke-virtual {v0, v7}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto/16 :goto_1652

    .line 5839
    :cond_ede
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v5, "_grplist_"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_f57

    .line 5840
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->r()V

    .line 5841
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x1

    .line 5842
    :goto_ef7
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_f3b

    add-int/lit8 v2, v1, 0x3

    .line 5843
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v3

    if-lt v2, v3, :cond_f06

    goto :goto_f3b

    .line 5844
    :cond_f06
    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10

    add-int/lit8 v3, v1, 0x1

    .line 5845
    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    move-object v11, v3

    check-cast v11, Ljava/lang/String;

    add-int/lit8 v3, v1, 0x2

    .line 5846
    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v12

    .line 5847
    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v14

    .line 5848
    new-instance v2, Lkz/qqqschulz/strike2d/MainActivity$m;

    move-object v9, v2

    invoke-direct/range {v9 .. v14}, Lkz/qqqschulz/strike2d/MainActivity$m;-><init>(ILjava/lang/String;JI)V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x4

    goto :goto_ef7

    .line 5850
    :cond_f3b
    :goto_f3b
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_f43

    goto/16 :goto_1652

    .line 5851
    :cond_f43
    new-instance v1, Lkz/qqqschulz/strike2d/MainActivity$n;

    invoke-direct {v1}, Lkz/qqqschulz/strike2d/MainActivity$n;-><init>()V

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 5852
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v2, Lkz/qqqschulz/strike2d/MainActivity$21$5;

    invoke-direct {v2, v8, v0}, Lkz/qqqschulz/strike2d/MainActivity$21$5;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;Ljava/util/ArrayList;)V

    invoke-virtual {v1, v2}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto/16 :goto_1652

    .line 5860
    :cond_f57
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v5, "_lastfrmsg_"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_fc5

    const/4 v0, 0x1

    .line 5861
    :goto_f66
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_1652

    add-int/lit8 v1, v0, 0x1

    .line 5862
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v2

    if-lt v1, v2, :cond_f76

    goto/16 :goto_1652

    .line 5863
    :cond_f76
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    .line 5864
    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v3

    .line 5865
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->CR:Ljava/util/HashMap;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_fb5

    .line 5866
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->CR:Ljava/util/HashMap;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    cmp-long v5, v3, v1

    if-lez v5, :cond_fc2

    .line 5867
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->FK:Z

    goto/16 :goto_1652

    :cond_fb5
    const/4 v1, 0x1

    const-wide/16 v5, 0x0

    cmp-long v2, v3, v5

    if-eqz v2, :cond_fc2

    .line 5872
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-boolean v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->FK:Z

    goto/16 :goto_1652

    :cond_fc2
    add-int/lit8 v0, v0, 0x2

    goto :goto_f66

    .line 5879
    :cond_fc5
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v5, "_lastgrmsg_"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1036

    const/4 v0, 0x1

    .line 5880
    :goto_fd4
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_1652

    add-int/lit8 v1, v0, 0x1

    .line 5881
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v2

    if-lt v1, v2, :cond_fe4

    goto/16 :goto_1652

    .line 5882
    :cond_fe4
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    .line 5883
    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v3

    .line 5884
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->Do:Ljava/util/HashMap;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1026

    .line 5885
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->Do:Ljava/util/HashMap;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    cmp-long v5, v3, v1

    if-lez v5, :cond_1023

    .line 5886
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->FL:Z

    goto/16 :goto_1652

    :cond_1023
    const-wide/16 v5, 0x0

    goto :goto_1033

    :cond_1026
    const/4 v1, 0x1

    const-wide/16 v5, 0x0

    cmp-long v2, v3, v5

    if-eqz v2, :cond_1033

    .line 5891
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-boolean v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->FL:Z

    goto/16 :goto_1652

    :cond_1033
    :goto_1033
    add-int/lit8 v0, v0, 0x2

    goto :goto_fd4

    .line 5898
    :cond_1036
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v5, "_lastnews_"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_105b

    const/4 v0, 0x1

    .line 5899
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    .line 5900
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->DJ:I

    if-le v1, v2, :cond_1652

    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-boolean v0, v1, Lkz/qqqschulz/strike2d/MainActivity;->FM:Z

    goto/16 :goto_1652

    .line 5903
    :cond_105b
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v5, "_partlisterror_"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_107e

    .line 5904
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->t()V

    .line 5905
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060083

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5908
    :cond_107e
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v5, "_frreqtwo_"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_109c

    .line 5909
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060174

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5912
    :cond_109c
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v5, "_frreqfr_"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_10ba

    .line 5913
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060009

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5916
    :cond_10ba
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v5, "_frreqmax_"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_10d8

    .line 5917
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060113

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5920
    :cond_10d8
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v5, "_frreqok_"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_10f6

    .line 5921
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060092

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 5924
    :cond_10f6
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v5, "_conntmpok_"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11d2

    const/4 v0, 0x1

    .line 5925
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/4 v5, 0x2

    .line 5926
    invoke-interface {v7, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    .line 5927
    invoke-interface {v7, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    .line 5928
    invoke-interface {v7, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    invoke-static {v10}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10

    .line 5929
    invoke-interface {v7, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v11

    .line 5930
    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    .line 5931
    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    const/16 v12, 0x8

    .line 5932
    invoke-interface {v7, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    invoke-static {v12}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v12

    .line 5933
    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    .line 5934
    invoke-interface {v7, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    const/16 v13, 0xb

    .line 5935
    invoke-interface {v7, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    invoke-static {v13}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v13

    .line 5936
    iget-object v14, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    const/16 v15, 0xc

    invoke-interface {v7, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-virtual {v14, v7}, Lkz/qqqschulz/strike2d/MainActivity;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 5937
    iget-object v14, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    const/4 v15, 0x1

    if-ne v13, v15, :cond_118d

    const/4 v13, 0x1

    goto :goto_118e

    :cond_118d
    const/4 v13, 0x0

    :goto_118e
    iput-boolean v13, v14, Lkz/qqqschulz/strike2d/MainActivity;->zn:Z

    .line 5938
    iget-object v13, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    if-ne v2, v15, :cond_1195

    const/4 v9, 0x1

    :cond_1195
    iput-boolean v9, v13, Lkz/qqqschulz/strike2d/MainActivity;->FJ:Z

    if-lez v0, :cond_1652

    .line 5940
    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->Gh:Ljava/lang/Object;

    monitor-enter v2

    .line 5941
    :try_start_119e
    iget-object v9, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput v0, v9, Lkz/qqqschulz/strike2d/MainActivity;->BN:I

    .line 5942
    iget-object v9, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput v5, v9, Lkz/qqqschulz/strike2d/MainActivity;->BP:I

    .line 5943
    iget-object v9, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput v4, v9, Lkz/qqqschulz/strike2d/MainActivity;->BO:I

    .line 5944
    iget-object v9, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v9, v5}, Lkz/qqqschulz/strike2d/MainActivity;->q(I)V

    .line 5945
    iget-object v5, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v5, v0}, Lkz/qqqschulz/strike2d/MainActivity;->i(I)V

    .line 5946
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0, v4}, Lkz/qqqschulz/strike2d/MainActivity;->j(I)V

    .line 5947
    monitor-exit v2
    :try_end_11ba
    .catchall {:try_start_119e .. :try_end_11ba} :catchall_11cf

    .line 5948
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput v6, v0, Lkz/qqqschulz/strike2d/MainActivity;->BQ:I

    .line 5949
    iput v10, v0, Lkz/qqqschulz/strike2d/MainActivity;->BR:I

    .line 5950
    iput v11, v0, Lkz/qqqschulz/strike2d/MainActivity;->BS:I

    .line 5951
    iput v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->BT:I

    .line 5952
    iput v3, v0, Lkz/qqqschulz/strike2d/MainActivity;->BU:I

    .line 5953
    iput v12, v0, Lkz/qqqschulz/strike2d/MainActivity;->BV:I

    .line 5954
    iput-object v7, v0, Lkz/qqqschulz/strike2d/MainActivity;->BW:Ljava/lang/String;

    const/4 v1, 0x1

    .line 5955
    iput-boolean v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->CE:Z

    goto/16 :goto_1652

    :catchall_11cf
    move-exception v0

    .line 5947
    :try_start_11d0
    monitor-exit v2
    :try_end_11d1
    .catchall {:try_start_11d0 .. :try_end_11d1} :catchall_11cf

    throw v0

    .line 5959
    :cond_11d2
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v5, "_connloginok_"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_12ef

    const/4 v0, 0x1

    .line 5960
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/4 v5, 0x2

    .line 5961
    invoke-interface {v7, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 5962
    invoke-interface {v7, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    .line 5963
    invoke-interface {v7, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    invoke-static {v10}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10

    .line 5964
    invoke-interface {v7, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v11

    .line 5965
    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    .line 5966
    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    const/16 v12, 0x8

    .line 5967
    invoke-interface {v7, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    invoke-static {v12}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v12

    .line 5968
    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    .line 5969
    invoke-interface {v7, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    const/16 v13, 0xb

    .line 5970
    invoke-interface {v7, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    invoke-static {v13}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v13

    const/16 v14, 0xc

    .line 5971
    invoke-interface {v7, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    invoke-static {v14}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v14

    const/16 v15, 0xd

    .line 5972
    invoke-interface {v7, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    invoke-static {v15}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v15

    .line 5973
    iget-object v9, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    move/from16 p1, v2

    const/16 v2, 0xe

    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v9, v2}, Lkz/qqqschulz/strike2d/MainActivity;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 5974
    iget-object v7, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    const/4 v9, 0x1

    if-ne v13, v9, :cond_127b

    const/4 v13, 0x1

    goto :goto_127c

    :cond_127b
    const/4 v13, 0x0

    :goto_127c
    iput-boolean v13, v7, Lkz/qqqschulz/strike2d/MainActivity;->FJ:Z

    .line 5975
    iget-object v7, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    if-ne v15, v9, :cond_1284

    const/4 v9, 0x1

    goto :goto_1285

    :cond_1284
    const/4 v9, 0x0

    :goto_1285
    iput-boolean v9, v7, Lkz/qqqschulz/strike2d/MainActivity;->zn:Z

    if-eqz v4, :cond_1291

    .line 5976
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v7

    const/16 v9, 0xf

    if-le v7, v9, :cond_1293

    :cond_1291
    const-string v4, "Player"

    :cond_1293
    if-lez v0, :cond_1652

    .line 5978
    iget-object v7, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v7, v5}, Lkz/qqqschulz/strike2d/MainActivity;->p(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_12a2

    .line 5979
    iget-object v7, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-object v5, v7, Lkz/qqqschulz/strike2d/MainActivity;->BM:Ljava/lang/String;

    goto :goto_12a7

    .line 5981
    :cond_12a2
    iget-object v5, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v5}, Lkz/qqqschulz/strike2d/MainActivity;->cf()V

    .line 5983
    :goto_12a7
    iget-object v5, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v5, v5, Lkz/qqqschulz/strike2d/MainActivity;->Gh:Ljava/lang/Object;

    monitor-enter v5

    .line 5984
    :try_start_12ac
    iget-object v7, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput v0, v7, Lkz/qqqschulz/strike2d/MainActivity;->BN:I

    .line 5985
    iget-object v7, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput v6, v7, Lkz/qqqschulz/strike2d/MainActivity;->BP:I

    .line 5986
    iget-object v7, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput v14, v7, Lkz/qqqschulz/strike2d/MainActivity;->BO:I

    .line 5987
    iget-object v7, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v7, v6}, Lkz/qqqschulz/strike2d/MainActivity;->q(I)V

    .line 5988
    iget-object v6, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v6, v0}, Lkz/qqqschulz/strike2d/MainActivity;->i(I)V

    .line 5989
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0, v14}, Lkz/qqqschulz/strike2d/MainActivity;->j(I)V

    .line 5990
    monitor-exit v5
    :try_end_12c8
    .catchall {:try_start_12ac .. :try_end_12c8} :catchall_12ec

    .line 5991
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput v10, v0, Lkz/qqqschulz/strike2d/MainActivity;->BQ:I

    .line 5992
    iput v11, v0, Lkz/qqqschulz/strike2d/MainActivity;->BR:I

    .line 5993
    iput v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->BS:I

    .line 5994
    iput v3, v0, Lkz/qqqschulz/strike2d/MainActivity;->BT:I

    .line 5995
    iput v12, v0, Lkz/qqqschulz/strike2d/MainActivity;->BU:I

    move/from16 v1, p1

    .line 5996
    iput v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->BV:I

    .line 5997
    iput-object v2, v0, Lkz/qqqschulz/strike2d/MainActivity;->BW:Ljava/lang/String;

    .line 5998
    iput-object v4, v0, Lkz/qqqschulz/strike2d/MainActivity;->qa:Ljava/lang/String;

    const/4 v1, 0x1

    .line 5999
    iput-boolean v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->CE:Z

    const/4 v2, 0x0

    .line 6000
    iput-boolean v2, v0, Lkz/qqqschulz/strike2d/MainActivity;->CF:Z

    .line 6001
    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->ap()V

    .line 6002
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->c(Z)V

    goto/16 :goto_1652

    :catchall_12ec
    move-exception v0

    .line 5990
    :try_start_12ed
    monitor-exit v5
    :try_end_12ee
    .catchall {:try_start_12ed .. :try_end_12ee} :catchall_12ec

    throw v0

    :cond_12ef
    const/4 v0, 0x0

    .line 6006
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v2, "_regok_"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1342

    .line 6007
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v1}, Lkz/qqqschulz/strike2d/MainActivity;->ap()V

    .line 6008
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-boolean v0, v1, Lkz/qqqschulz/strike2d/MainActivity;->CF:Z

    .line 6009
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v3, 0x7f060002

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " \""

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->CG:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\""

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v3, 0x7f060142

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 6012
    :cond_1342
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v0, "_regloginerror_"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1376

    .line 6013
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->CG:Ljava/lang/String;

    .line 6014
    iput-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->CH:Ljava/lang/String;

    const-string v1, ""

    .line 6015
    iput-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->CI:Ljava/lang/String;

    const-string v1, ""

    .line 6016
    iput-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->CJ:Ljava/lang/String;

    const-string v1, ""

    .line 6017
    iput-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->CK:Ljava/lang/String;

    .line 6018
    iput v3, v0, Lkz/qqqschulz/strike2d/MainActivity;->Be:I

    const/4 v1, 0x1

    .line 6019
    iput-boolean v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->ft:Z

    .line 6020
    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f06014d

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    :cond_1376
    const/4 v0, 0x0

    .line 6023
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    const-string v0, "_regerror_"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1399

    .line 6024
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->CG:Ljava/lang/String;

    .line 6025
    iput-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->CH:Ljava/lang/String;

    .line 6026
    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f06011f

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    :cond_1399
    const/4 v0, 0x0

    .line 6029
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    const-string v0, "_connloginerror_"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_13c7

    .line 6030
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v3, 0x7f0600bc

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    .line 6031
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iput-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->CG:Ljava/lang/String;

    .line 6032
    iput-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->CH:Ljava/lang/String;

    .line 6033
    iget-boolean v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->CF:Z

    if-nez v0, :cond_1652

    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->bu()V

    goto/16 :goto_1652

    :cond_13c7
    const/4 v0, 0x0

    .line 6036
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v2, "_delaccok_"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_13e6

    .line 6037
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060003

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 6040
    :cond_13e6
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v0, "_getkey_"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1436

    .line 6041
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "_getkey_\b"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0xc

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\b"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->BM:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\b"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Lkz/qqqschulz/strike2d/MainActivity;->h(Z)J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    invoke-static {v2, v3, v4}, Lkz/qqqschulz/strike2d/MainActivity;->a(Lkz/qqqschulz/strike2d/MainActivity;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->h(Ljava/lang/String;)V

    goto/16 :goto_1652

    :cond_1436
    const/4 v3, 0x0

    .line 6044
    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_delaccerror_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1455

    .line 6045
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f06007e

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 6048
    :cond_1455
    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_chpassok_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1483

    .line 6049
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    const/4 v1, 0x1

    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iput-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->CH:Ljava/lang/String;

    .line 6050
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->ap()V

    .line 6051
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f060104

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    :cond_1483
    const/4 v0, 0x0

    .line 6054
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v2, "_chpasserror_"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_14a2

    .line 6055
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f06016e

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    .line 6058
    :cond_14a2
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v0, "_nofound_"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_14c5

    .line 6059
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->z()V

    .line 6060
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->aF:Landroid/content/Context;

    const v2, 0x7f0600f3

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lkz/qqqschulz/strike2d/MainActivity;->n(Ljava/lang/String;)V

    goto/16 :goto_1652

    :cond_14c5
    const/4 v0, 0x0

    .line 6063
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v0, "_resfound_"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1530

    .line 6064
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->z()V

    .line 6065
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 6066
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 6067
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x1

    .line 6068
    :goto_14e9
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v4

    if-ge v3, v4, :cond_1524

    add-int/lit8 v4, v3, 0x2

    .line 6069
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v5

    if-lt v4, v5, :cond_14f8

    goto :goto_1524

    .line 6070
    :cond_14f8
    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v5, v3, 0x1

    .line 6071
    invoke-interface {v7, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 6072
    iget-object v5, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-interface {v7, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v5, v4}, Lkz/qqqschulz/strike2d/MainActivity;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x3

    goto :goto_14e9

    .line 6074
    :cond_1524
    :goto_1524
    iget-object v3, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v4, Lkz/qqqschulz/strike2d/MainActivity$21$6;

    invoke-direct {v4, v8, v0, v1, v2}, Lkz/qqqschulz/strike2d/MainActivity$21$6;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    invoke-virtual {v3, v4}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto/16 :goto_1652

    :cond_1530
    const/4 v0, 0x0

    .line 6082
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v0, "_getsrv_"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_156a

    .line 6083
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x2

    if-ge v0, v1, :cond_1548

    goto/16 :goto_1652

    .line 6084
    :cond_1548
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->aA:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v0, 0x1

    .line 6085
    :goto_1550
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_1652

    .line 6087
    :try_start_1556
    iget-object v1, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->aA:Ljava/util/List;

    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1567
    .catch Ljava/io/IOException; {:try_start_1556 .. :try_end_1567} :catch_1567

    :catch_1567
    add-int/lit8 v0, v0, 0x1

    goto :goto_1550

    :cond_156a
    const/4 v0, 0x0

    .line 6093
    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v0, "_ltoday_"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15df

    .line 6094
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Dy:I

    const/4 v10, 0x1

    if-eq v0, v10, :cond_1582

    goto/16 :goto_1652

    .line 6095
    :cond_1582
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->u()V

    .line 6096
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 6097
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 6098
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 6099
    :goto_1596
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v3

    if-ge v10, v3, :cond_15d3

    add-int/lit8 v3, v10, 0x2

    .line 6100
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v4

    if-lt v3, v4, :cond_15a5

    goto :goto_15d3

    .line 6101
    :cond_15a5
    invoke-interface {v7, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    .line 6102
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v10, 0x1

    .line 6103
    invoke-interface {v7, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 6104
    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v10, v10, 0x3

    goto :goto_1596

    .line 6106
    :cond_15d3
    :goto_15d3
    iget-object v3, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v4, Lkz/qqqschulz/strike2d/MainActivity$21$7;

    invoke-direct {v4, v8, v0, v1, v2}, Lkz/qqqschulz/strike2d/MainActivity$21$7;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    invoke-virtual {v3, v4}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto/16 :goto_1652

    :cond_15df
    const/4 v2, 0x0

    const/4 v10, 0x1

    .line 6114
    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "_lweek_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1652

    .line 6115
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Dy:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_15f7

    goto :goto_1652

    .line 6116
    :cond_15f7
    iget-object v0, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->u()V

    .line 6117
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 6118
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 6119
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 6120
    :goto_160b
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v3

    if-ge v10, v3, :cond_1648

    add-int/lit8 v3, v10, 0x2

    .line 6121
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v4

    if-lt v3, v4, :cond_161a

    goto :goto_1648

    .line 6122
    :cond_161a
    invoke-interface {v7, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    .line 6123
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v10, 0x1

    .line 6124
    invoke-interface {v7, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 6125
    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v10, v10, 0x3

    goto :goto_160b

    .line 6127
    :cond_1648
    :goto_1648
    iget-object v3, v8, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v4, Lkz/qqqschulz/strike2d/MainActivity$21$8;

    invoke-direct {v4, v8, v0, v1, v2}, Lkz/qqqschulz/strike2d/MainActivity$21$8;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    invoke-virtual {v3, v4}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_1652
    :goto_1652
    return-void

    :cond_1653
    :goto_1653
    return-void
.end method

.method a(Ljava/util/List;)V
    .registers 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    if-eqz v1, :cond_b3

    .line 6140
    invoke-interface/range {p1 .. p1}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_e

    goto/16 :goto_b3

    .line 6141
    :cond_e
    iget-object v2, v0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v2}, Lkz/qqqschulz/strike2d/MainActivity;->n()V

    .line 6142
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x1

    .line 6143
    :goto_19
    invoke-interface/range {p1 .. p1}, Ljava/util/List;->size()I

    move-result v4

    if-ge v3, v4, :cond_a2

    .line 6144
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    add-int/lit8 v4, v3, 0x1

    .line 6145
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    move-object v9, v4

    check-cast v9, Ljava/lang/String;

    add-int/lit8 v4, v3, 0x2

    .line 6146
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v13

    add-int/lit8 v4, v3, 0x3

    .line 6147
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    move-object v14, v4

    check-cast v14, Ljava/lang/String;

    add-int/lit8 v4, v3, 0x4

    .line 6148
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    move-object v12, v4

    check-cast v12, Ljava/lang/String;

    add-int/lit8 v4, v3, 0x5

    .line 6149
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10

    add-int/lit8 v4, v3, 0x6

    .line 6150
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v11

    add-int/lit8 v4, v3, 0x7

    .line 6151
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    move-object v7, v4

    check-cast v7, Ljava/lang/String;

    add-int/lit8 v4, v3, 0x8

    .line 6152
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v15

    add-int/lit8 v4, v3, 0x9

    .line 6153
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v16

    add-int/lit8 v4, v3, 0xa

    .line 6154
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v17, v4

    check-cast v17, Ljava/lang/String;

    .line 6155
    new-instance v4, Lkz/qqqschulz/strike2d/MainActivity$z;

    iget-object v6, v0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    move-object v5, v4

    invoke-direct/range {v5 .. v17}, Lkz/qqqschulz/strike2d/MainActivity$z;-><init>(Lkz/qqqschulz/strike2d/MainActivity;Ljava/lang/String;ILjava/lang/String;IILjava/lang/String;ILjava/lang/String;IILjava/lang/String;)V

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0xb

    goto/16 :goto_19

    .line 6157
    :cond_a2
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_b2

    .line 6158
    iget-object v1, v0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v3, Lkz/qqqschulz/strike2d/MainActivity$21$9;

    invoke-direct {v3, v0, v2}, Lkz/qqqschulz/strike2d/MainActivity$21$9;-><init>(Lkz/qqqschulz/strike2d/MainActivity$21;Ljava/util/ArrayList;)V

    invoke-virtual {v1, v3}, Lkz/qqqschulz/strike2d/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_b2
    return-void

    :cond_b3
    :goto_b3
    return-void
.end method

.method public run()V
    .registers 4

    .line 6169
    iget-object v0, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->FB:I

    .line 6170
    :cond_4
    :goto_4
    iget-object v1, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->FB:I

    if-ne v0, v1, :cond_33

    iget-object v1, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->Fz:Ljava/lang/Thread;

    if-eqz v1, :cond_33

    .line 6172
    :try_start_10
    invoke-virtual {p0}, Lkz/qqqschulz/strike2d/MainActivity$21;->a()I

    move-result v1

    const/4 v2, -0x1

    if-ne v1, v2, :cond_4

    .line 6174
    iget-object v1, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->Fz:Ljava/lang/Thread;

    monitor-enter v1
    :try_end_1c
    .catch Ljava/lang/NullPointerException; {:try_start_10 .. :try_end_1c} :catch_2e

    .line 6176
    :try_start_1c
    iget-object v2, p0, Lkz/qqqschulz/strike2d/MainActivity$21;->a:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v2, v2, Lkz/qqqschulz/strike2d/MainActivity;->Fz:Ljava/lang/Thread;

    invoke-virtual {v2}, Ljava/lang/Object;->wait()V
    :try_end_23
    .catch Ljava/lang/InterruptedException; {:try_start_1c .. :try_end_23} :catch_26
    .catchall {:try_start_1c .. :try_end_23} :catchall_24

    goto :goto_2a

    :catchall_24
    move-exception v2

    goto :goto_2c

    :catch_26
    move-exception v2

    .line 6178
    :try_start_27
    invoke-virtual {v2}, Ljava/lang/InterruptedException;->printStackTrace()V

    .line 6180
    :goto_2a
    monitor-exit v1

    goto :goto_4

    :goto_2c
    monitor-exit v1
    :try_end_2d
    .catchall {:try_start_27 .. :try_end_2d} :catchall_24

    :try_start_2d
    throw v2
    :try_end_2e
    .catch Ljava/lang/NullPointerException; {:try_start_2d .. :try_end_2e} :catch_2e

    :catch_2e
    move-exception v1

    .line 6183
    invoke-virtual {v1}, Ljava/lang/NullPointerException;->printStackTrace()V

    goto :goto_4

    :cond_33
    return-void
.end method
