.class Lkz/qqqschulz/strike2d/MainActivity$56;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkz/qqqschulz/strike2d/MainActivity;->y(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Lkz/qqqschulz/strike2d/MainActivity;


# direct methods
.method constructor <init>(Lkz/qqqschulz/strike2d/MainActivity;I)V
    .registers 3

    .line 3153
    iput-object p1, p0, Lkz/qqqschulz/strike2d/MainActivity$56;->b:Lkz/qqqschulz/strike2d/MainActivity;

    iput p2, p0, Lkz/qqqschulz/strike2d/MainActivity$56;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    .line 3156
    iget-object v0, p0, Lkz/qqqschulz/strike2d/MainActivity$56;->b:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Do:Ljava/util/HashMap;

    iget v1, p0, Lkz/qqqschulz/strike2d/MainActivity$56;->a:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 3158
    :goto_d
    iget-object v0, p0, Lkz/qqqschulz/strike2d/MainActivity$56;->b:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->Dk:Ljava/util/List;

    iget v1, p0, Lkz/qqqschulz/strike2d/MainActivity$56;->a:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_26

    .line 3167
    iget-object v0, p0, Lkz/qqqschulz/strike2d/MainActivity$56;->b:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->pI:Lkz/qqqschulz/strike2d/MainActivity$o;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity$o;->notifyDataSetChanged()V

    return-void

    .line 3160
    :cond_26
    iget-object v1, p0, Lkz/qqqschulz/strike2d/MainActivity$56;->b:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->Dj:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 3161
    iget-object v1, p0, Lkz/qqqschulz/strike2d/MainActivity$56;->b:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->Dk:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 3162
    iget-object v1, p0, Lkz/qqqschulz/strike2d/MainActivity$56;->b:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->Dl:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 3163
    iget-object v1, p0, Lkz/qqqschulz/strike2d/MainActivity$56;->b:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->Dm:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 3164
    iget-object v1, p0, Lkz/qqqschulz/strike2d/MainActivity$56;->b:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v1, v1, Lkz/qqqschulz/strike2d/MainActivity;->Dn:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 3165
    iget-object v0, p0, Lkz/qqqschulz/strike2d/MainActivity$56;->b:Lkz/qqqschulz/strike2d/MainActivity;

    iget v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->Dp:I

    add-int/lit8 v1, v1, -0x1

    iput v1, v0, Lkz/qqqschulz/strike2d/MainActivity;->Dp:I

    goto :goto_d
.end method
