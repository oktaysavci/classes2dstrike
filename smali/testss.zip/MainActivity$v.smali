.class Lkz/qqqschulz/strike2d/MainActivity$v;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkz/qqqschulz/strike2d/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "v"
.end annotation


# instance fields
.field a:I

.field b:Ljava/lang/String;

.field final synthetic c:Lkz/qqqschulz/strike2d/MainActivity;


# direct methods
.method constructor <init>(Lkz/qqqschulz/strike2d/MainActivity;ILjava/lang/String;)V
    .registers 4

    .line 42644
    iput-object p1, p0, Lkz/qqqschulz/strike2d/MainActivity$v;->c:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 42645
    iput p2, p0, Lkz/qqqschulz/strike2d/MainActivity$v;->a:I

    .line 42646
    iput-object p3, p0, Lkz/qqqschulz/strike2d/MainActivity$v;->b:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 22

    move-object/from16 v1, p0

    .line 42650
    iget-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->b:Ljava/lang/String;

    if-eqz v0, :cond_16d

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_e

    goto/16 :goto_16d

    .line 42651
    :cond_e
    iget-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->c:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->b:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ".map"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lkz/qqqschulz/strike2d/MainActivity;->getFileStreamPath(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    .line 42652
    iget-object v2, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->c:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->b:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ".ob"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lkz/qqqschulz/strike2d/MainActivity;->getFileStreamPath(Ljava/lang/String;)Ljava/io/File;

    move-result-object v2

    .line 42653
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v3

    if-eqz v3, :cond_16c

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v3

    if-nez v3, :cond_4e

    goto/16 :goto_16c

    .line 42655
    :cond_4e
    :try_start_4e
    new-instance v3, Ljava/io/DataInputStream;

    new-instance v4, Ljava/io/FileInputStream;

    invoke-direct {v4, v0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    invoke-direct {v3, v4}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    .line 42656
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readByte()B

    move-result v6

    .line 42657
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v7

    .line 42658
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v8

    .line 42659
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readInt()I

    move-result v9

    .line 42660
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readInt()I

    move-result v10

    .line 42661
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readShort()S

    move-result v11

    .line 42662
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readShort()S

    move-result v12

    .line 42663
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v13

    .line 42664
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readInt()I

    move-result v14

    .line 42665
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readShort()S

    move-result v15

    .line 42666
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readShort()S

    move-result v16

    .line 42667
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readShort()S

    move-result v17

    .line 42668
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readShort()S

    move-result v18

    .line 42669
    iget-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->c:Lkz/qqqschulz/strike2d/MainActivity;

    new-instance v4, Lkz/qqqschulz/strike2d/MainActivity$d;

    move-object v5, v4

    invoke-direct/range {v5 .. v18}, Lkz/qqqschulz/strike2d/MainActivity$d;-><init>(BLjava/lang/String;Ljava/lang/String;IISSLjava/lang/String;ISSSS)V

    iput-object v4, v0, Lkz/qqqschulz/strike2d/MainActivity;->JA:Lkz/qqqschulz/strike2d/MainActivity$d;

    .line 42670
    iget-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->c:Lkz/qqqschulz/strike2d/MainActivity;

    iget v4, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->a:I

    iget-object v5, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->c:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v5, v5, Lkz/qqqschulz/strike2d/MainActivity;->JA:Lkz/qqqschulz/strike2d/MainActivity$d;

    invoke-virtual {v0, v4, v5}, Lkz/qqqschulz/strike2d/MainActivity;->a(ILkz/qqqschulz/strike2d/MainActivity$d;)V

    const-wide/16 v4, 0xa

    .line 42671
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V

    .line 42672
    iget-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->c:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->IW:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 42673
    iget-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->c:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->IX:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 42674
    :goto_b4
    invoke-virtual {v3}, Ljava/io/DataInputStream;->available()I

    move-result v0

    if-lez v0, :cond_102

    .line 42675
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v7

    .line 42676
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readByte()B

    move-result v10

    .line 42677
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readShort()S

    move-result v0

    .line 42678
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readShort()S

    move-result v6

    .line 42679
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readShort()S

    move-result v8

    .line 42680
    invoke-virtual {v3}, Ljava/io/DataInputStream;->readShort()S

    move-result v9

    .line 42681
    iget-object v11, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->c:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v15, v11, Lkz/qqqschulz/strike2d/MainActivity;->IW:Ljava/util/List;

    new-instance v14, Lkz/qqqschulz/strike2d/MainActivity$j;

    const/4 v11, 0x0

    const/4 v12, 0x0

    int-to-float v0, v0

    int-to-float v13, v6

    int-to-float v8, v8

    int-to-float v9, v9

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    move-object v6, v14

    move/from16 v19, v8

    move v8, v11

    move/from16 v20, v9

    move v9, v12

    move v11, v0

    move v12, v13

    move/from16 v13, v19

    move-object v0, v14

    move/from16 v14, v20

    move-object v4, v15

    move/from16 v15, v16

    move/from16 v16, v17

    move/from16 v17, v18

    invoke-direct/range {v6 .. v17}, Lkz/qqqschulz/strike2d/MainActivity$j;-><init>(Ljava/lang/String;IIIFFFFIZZ)V

    invoke-interface {v4, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-wide/16 v4, 0xa

    goto :goto_b4

    .line 42683
    :cond_102
    invoke-virtual {v3}, Ljava/io/DataInputStream;->close()V

    .line 42684
    iget-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->c:Lkz/qqqschulz/strike2d/MainActivity;

    iget v3, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->a:I

    invoke-virtual {v0, v3}, Lkz/qqqschulz/strike2d/MainActivity;->ay(I)V

    const-wide/16 v3, 0xa

    .line 42685
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V

    .line 42686
    new-instance v0, Ljava/io/DataInputStream;

    new-instance v3, Ljava/io/FileInputStream;

    invoke-direct {v3, v2}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    invoke-direct {v0, v3}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    .line 42687
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readByte()B

    .line 42688
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    .line 42689
    :goto_121
    invoke-virtual {v0}, Ljava/io/DataInputStream;->available()I

    move-result v2

    if-lez v2, :cond_140

    .line 42690
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readByte()B

    move-result v2

    .line 42691
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readShort()S

    move-result v3

    .line 42692
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readShort()S

    move-result v4

    .line 42693
    iget-object v5, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->c:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v5, v5, Lkz/qqqschulz/strike2d/MainActivity;->IX:Ljava/util/List;

    new-instance v6, Lkz/qqqschulz/strike2d/MainActivity$k;

    invoke-direct {v6, v2, v3, v4}, Lkz/qqqschulz/strike2d/MainActivity$k;-><init>(BSS)V

    invoke-interface {v5, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_121

    .line 42695
    :cond_140
    invoke-virtual {v0}, Ljava/io/DataInputStream;->close()V

    .line 42696
    iget-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->c:Lkz/qqqschulz/strike2d/MainActivity;

    iget v2, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->a:I

    invoke-virtual {v0, v2}, Lkz/qqqschulz/strike2d/MainActivity;->az(I)V

    const-wide/16 v2, 0xa

    .line 42697
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V

    .line 42698
    iget-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->c:Lkz/qqqschulz/strike2d/MainActivity;

    iget v2, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->a:I

    iget-object v3, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->b:Ljava/lang/String;

    invoke-virtual {v0, v2, v3}, Lkz/qqqschulz/strike2d/MainActivity;->d(ILjava/lang/String;)V

    .line 42699
    iget-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->c:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->IW:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 42700
    iget-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity$v;->c:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->IX:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V
    :try_end_166
    .catch Ljava/lang/Exception; {:try_start_4e .. :try_end_166} :catch_167

    goto :goto_16b

    :catch_167
    move-exception v0

    .line 42702
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_16b
    return-void

    :cond_16c
    :goto_16c
    return-void

    :cond_16d
    :goto_16d
    return-void
.end method
