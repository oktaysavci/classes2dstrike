.class Lkz/qqqschulz/strike2d/MainActivity$53;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkz/qqqschulz/strike2d/MainActivity;->a(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Z

.field final synthetic b:Lkz/qqqschulz/strike2d/MainActivity;


# direct methods
.method constructor <init>(Lkz/qqqschulz/strike2d/MainActivity;Z)V
    .registers 3

    .line 3063
    iput-object p1, p0, Lkz/qqqschulz/strike2d/MainActivity$53;->b:Lkz/qqqschulz/strike2d/MainActivity;

    iput-boolean p2, p0, Lkz/qqqschulz/strike2d/MainActivity$53;->a:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 18

    move-object/from16 v1, p0

    .line 3065
    iget-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity$53;->b:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->m()V

    .line 3066
    iget-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity$53;->b:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->o()Ljava/io/File;

    move-result-object v2

    if-eqz v2, :cond_9d

    .line 3067
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_9d

    .line 3068
    invoke-virtual {v2}, Ljava/io/File;->list()[Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_1c

    return-void

    .line 3070
    :cond_1c
    array-length v4, v3

    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_1f
    if-ge v6, v4, :cond_9d

    aget-object v0, v3, v6

    const-string v7, ".map"

    .line 3071
    invoke-virtual {v0, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_9a

    const-string v7, ".map"

    const-string v8, ".ob"

    .line 3072
    invoke-virtual {v0, v7, v8}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v7

    .line 3073
    new-instance v8, Ljava/io/File;

    invoke-direct {v8, v2, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 3074
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v2, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 3075
    invoke-virtual {v8}, Ljava/io/File;->exists()Z

    move-result v7

    if-eqz v7, :cond_9a

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_9a

    .line 3077
    :try_start_49
    new-instance v0, Ljava/io/DataInputStream;

    new-instance v7, Ljava/io/FileInputStream;

    invoke-direct {v7, v8}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    invoke-direct {v0, v7}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    .line 3078
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readByte()B

    .line 3079
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v10

    .line 3080
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v11

    .line 3081
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readInt()I

    move-result v12

    .line 3082
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readInt()I

    move-result v7

    .line 3083
    iget-object v8, v1, Lkz/qqqschulz/strike2d/MainActivity$53;->b:Lkz/qqqschulz/strike2d/MainActivity;

    iget v8, v8, Lkz/qqqschulz/strike2d/MainActivity;->BN:I

    if-eq v12, v8, :cond_78

    if-eqz v12, :cond_78

    iget-object v8, v1, Lkz/qqqschulz/strike2d/MainActivity$53;->b:Lkz/qqqschulz/strike2d/MainActivity;

    iget v8, v8, Lkz/qqqschulz/strike2d/MainActivity;->rB:I

    if-ne v7, v8, :cond_75

    goto :goto_78

    :cond_75
    const/16 v16, 0x0

    goto :goto_7b

    :cond_78
    :goto_78
    const/4 v7, 0x1

    const/16 v16, 0x1

    .line 3084
    :goto_7b
    iget-boolean v7, v1, Lkz/qqqschulz/strike2d/MainActivity$53;->a:Z

    if-nez v7, :cond_81

    if-eqz v16, :cond_92

    .line 3085
    :cond_81
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readShort()S

    move-result v13

    .line 3086
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readShort()S

    move-result v14

    .line 3087
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v15

    .line 3088
    iget-object v9, v1, Lkz/qqqschulz/strike2d/MainActivity$53;->b:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual/range {v9 .. v16}, Lkz/qqqschulz/strike2d/MainActivity;->a(Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Z)V

    .line 3090
    :cond_92
    invoke-virtual {v0}, Ljava/io/DataInputStream;->close()V
    :try_end_95
    .catch Ljava/io/IOException; {:try_start_49 .. :try_end_95} :catch_96

    goto :goto_9a

    :catch_96
    move-exception v0

    .line 3092
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    :cond_9a
    :goto_9a
    add-int/lit8 v6, v6, 0x1

    goto :goto_1f

    .line 3098
    :cond_9d
    iget-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity$53;->b:Lkz/qqqschulz/strike2d/MainActivity;

    iget-object v0, v0, Lkz/qqqschulz/strike2d/MainActivity;->pL:Lkz/qqqschulz/strike2d/MainActivity$r;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity$r;->notifyDataSetChanged()V

    .line 3099
    iget-boolean v0, v1, Lkz/qqqschulz/strike2d/MainActivity$53;->a:Z

    if-nez v0, :cond_ad

    iget-object v0, v1, Lkz/qqqschulz/strike2d/MainActivity$53;->b:Lkz/qqqschulz/strike2d/MainActivity;

    invoke-virtual {v0}, Lkz/qqqschulz/strike2d/MainActivity;->I()V

    :cond_ad
    return-void
.end method
