.class public final Lcom/unity3d/ads/R;
.super Ljava/lang/Object;
.source "R.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
