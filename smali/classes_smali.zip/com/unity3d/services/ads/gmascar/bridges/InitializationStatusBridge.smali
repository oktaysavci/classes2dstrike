.class public Lcom/unity3d/services/ads/gmascar/bridges/InitializationStatusBridge;
.super Lcom/unity3d/services/ads/gmascar/bridges/GenericBridge;
.source "InitializationStatusBridge.java"


# static fields
.field private static final adapterStatusMapMethodName:Ljava/lang/String; = "getAdapterStatusMap"


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 10
    new-instance v0, Lcom/unity3d/services/ads/gmascar/bridges/InitializationStatusBridge$1;

    invoke-direct {v0}, Lcom/unity3d/services/ads/gmascar/bridges/InitializationStatusBridge$1;-><init>()V

    invoke-direct {p0, v0}, Lcom/unity3d/services/ads/gmascar/bridges/GenericBridge;-><init>(Ljava/util/Map;)V

    return-void
.end method


# virtual methods
.method public getAdapterStatusMap(Ljava/lang/Object;)Ljava/util/Map;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const-string v0, "getAdapterStatusMap"

    const/4 v1, 0x0

    .line 20
    new-array v1, v1, [Ljava/lang/Object;

    invoke-virtual {p0, v0, p1, v1}, Lcom/unity3d/services/ads/gmascar/bridges/InitializationStatusBridge;->callNonVoidMethod(Ljava/lang/String;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map;

    return-object p1
.end method

.method public getClassName()Ljava/lang/String;
    .registers 2

    const-string v0, "com.google.android.gms.ads.initialization.InitializationStatus"

    return-object v0
.end method
