.class public Lcom/unity3d/services/ads/gmascar/adapters/ScarAdapterFactory;
.super Ljava/lang/Object;
.source "ScarAdapterFactory.java"


# static fields
.field public static final CODE_19_2:I = 0xc043ba0

.field public static final CODE_19_5:I = 0xc1fb2e0

.field public static final CODE_19_7:I = 0xc2be7e0

.field public static final CODE_20_0:I = 0xc8a7ad0


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public createScarAdapter(JLcom/unity3d/a/a/a/d;)Lcom/unity3d/a/a/a/e;
    .registers 7

    const-wide/32 v0, 0xc8a7ad0

    cmp-long v2, p1, v0

    if-ltz v2, :cond_d

    .line 16
    new-instance p1, Lcom/unity3d/a/a/d/a;

    invoke-direct {p1, p3}, Lcom/unity3d/a/a/d/a;-><init>(Lcom/unity3d/a/a/a/d;)V

    goto :goto_3e

    :cond_d
    const-wide/32 v0, 0xc1fb2e0

    cmp-long v2, p1, v0

    if-ltz v2, :cond_21

    const-wide/32 v0, 0xc2be7e0

    cmp-long v2, p1, v0

    if-gtz v2, :cond_21

    .line 18
    new-instance p1, Lcom/unity3d/a/a/c/a;

    invoke-direct {p1, p3}, Lcom/unity3d/a/a/c/a;-><init>(Lcom/unity3d/a/a/a/d;)V

    goto :goto_3e

    :cond_21
    const-wide/32 v0, 0xc043ba0

    cmp-long v2, p1, v0

    if-ltz v2, :cond_2e

    .line 20
    new-instance p1, Lcom/unity3d/a/a/b/a;

    invoke-direct {p1, p3}, Lcom/unity3d/a/a/b/a;-><init>(Lcom/unity3d/a/a/a/d;)V

    goto :goto_3e

    :cond_2e
    const-string p3, "SCAR version %s is not supported."

    const/4 v0, 0x1

    .line 22
    new-array v0, v0, [Ljava/lang/Object;

    const/4 v1, 0x0

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    aput-object p1, v0, v1

    invoke-static {p3, v0}, Lcom/unity3d/services/core/log/DeviceLog;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 p1, 0x0

    :goto_3e
    return-object p1
.end method
