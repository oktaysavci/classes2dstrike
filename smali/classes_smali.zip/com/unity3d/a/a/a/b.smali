.class public Lcom/unity3d/a/a/a/b;
.super Lcom/unity3d/a/a/a/k;
.source "GMAAdsError.java"


# direct methods
.method public varargs constructor <init>(Lcom/unity3d/a/a/a/c;Ljava/lang/String;[Ljava/lang/Object;)V
    .registers 4

    .line 14
    invoke-direct {p0, p1, p2, p3}, Lcom/unity3d/a/a/a/k;-><init>(Lcom/unity3d/a/a/a/c;Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method

.method public varargs constructor <init>(Lcom/unity3d/a/a/a/c;[Ljava/lang/Object;)V
    .registers 4

    const/4 v0, 0x0

    .line 10
    invoke-direct {p0, p1, v0, p2}, Lcom/unity3d/a/a/a/k;-><init>(Lcom/unity3d/a/a/a/c;Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method

.method public static a(Lcom/unity3d/a/a/a/a/c;)Lcom/unity3d/a/a/a/b;
    .registers 5

    const-string v0, "Cannot show ad that is not loaded for placement %s"

    const/4 v1, 0x1

    .line 28
    new-array v1, v1, [Ljava/lang/Object;

    invoke-virtual {p0}, Lcom/unity3d/a/a/a/a/c;->a()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/unity3d/a/a/a/b;->a(Lcom/unity3d/a/a/a/a/c;Ljava/lang/String;)Lcom/unity3d/a/a/a/b;

    move-result-object p0

    return-object p0
.end method

.method public static a(Lcom/unity3d/a/a/a/a/c;Ljava/lang/String;)Lcom/unity3d/a/a/a/b;
    .registers 7

    .line 32
    new-instance v0, Lcom/unity3d/a/a/a/b;

    sget-object v1, Lcom/unity3d/a/a/a/c;->n:Lcom/unity3d/a/a/a/c;

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    invoke-virtual {p0}, Lcom/unity3d/a/a/a/a/c;->a()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    aput-object v3, v2, v4

    invoke-virtual {p0}, Lcom/unity3d/a/a/a/a/c;->b()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    aput-object p0, v2, v3

    const/4 p0, 0x2

    aput-object p1, v2, p0

    invoke-direct {v0, v1, p1, v2}, Lcom/unity3d/a/a/a/b;-><init>(Lcom/unity3d/a/a/a/c;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object v0
.end method

.method public static a(Ljava/lang/String;)Lcom/unity3d/a/a/a/b;
    .registers 5

    .line 44
    new-instance v0, Lcom/unity3d/a/a/a/b;

    sget-object v1, Lcom/unity3d/a/a/a/c;->f:Lcom/unity3d/a/a/a/c;

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-direct {v0, v1, p0, v2}, Lcom/unity3d/a/a/a/b;-><init>(Lcom/unity3d/a/a/a/c;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object v0
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/unity3d/a/a/a/b;
    .registers 7

    .line 24
    new-instance v0, Lcom/unity3d/a/a/a/b;

    sget-object v1, Lcom/unity3d/a/a/a/c;->l:Lcom/unity3d/a/a/a/c;

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 p0, 0x1

    aput-object p1, v2, p0

    const/4 p0, 0x2

    aput-object p2, v2, p0

    invoke-direct {v0, v1, p2, v2}, Lcom/unity3d/a/a/a/b;-><init>(Lcom/unity3d/a/a/a/c;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object v0
.end method

.method public static b(Lcom/unity3d/a/a/a/a/c;)Lcom/unity3d/a/a/a/b;
    .registers 5

    const-string v0, "Missing queryInfoMetadata for ad %s"

    const/4 v1, 0x1

    .line 36
    new-array v1, v1, [Ljava/lang/Object;

    invoke-virtual {p0}, Lcom/unity3d/a/a/a/a/c;->a()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/unity3d/a/a/a/b;->b(Lcom/unity3d/a/a/a/a/c;Ljava/lang/String;)Lcom/unity3d/a/a/a/b;

    move-result-object p0

    return-object p0
.end method

.method public static b(Lcom/unity3d/a/a/a/a/c;Ljava/lang/String;)Lcom/unity3d/a/a/a/b;
    .registers 7

    .line 40
    new-instance v0, Lcom/unity3d/a/a/a/b;

    sget-object v1, Lcom/unity3d/a/a/a/c;->j:Lcom/unity3d/a/a/a/c;

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    invoke-virtual {p0}, Lcom/unity3d/a/a/a/a/c;->a()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    aput-object v3, v2, v4

    invoke-virtual {p0}, Lcom/unity3d/a/a/a/a/c;->b()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    aput-object p0, v2, v3

    const/4 p0, 0x2

    aput-object p1, v2, p0

    invoke-direct {v0, v1, p1, v2}, Lcom/unity3d/a/a/a/b;-><init>(Lcom/unity3d/a/a/a/c;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .registers 2

    const-string v0, "GMA"

    return-object v0
.end method
