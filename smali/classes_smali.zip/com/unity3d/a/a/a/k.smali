.class public Lcom/unity3d/a/a/a/k;
.super Ljava/lang/Object;
.source "WebViewAdsError.java"

# interfaces
.implements Lcom/unity3d/a/a/a/h;


# instance fields
.field protected a:Ljava/lang/String;

.field protected b:[Ljava/lang/Object;

.field private c:Ljava/lang/Enum;


# direct methods
.method public varargs constructor <init>(Lcom/unity3d/a/a/a/c;Ljava/lang/String;[Ljava/lang/Object;)V
    .registers 4

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    iput-object p1, p0, Lcom/unity3d/a/a/a/k;->c:Ljava/lang/Enum;

    .line 10
    iput-object p2, p0, Lcom/unity3d/a/a/a/k;->a:Ljava/lang/String;

    .line 11
    iput-object p3, p0, Lcom/unity3d/a/a/a/k;->b:[Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public b()Ljava/lang/Enum;
    .registers 2

    .line 30
    iget-object v0, p0, Lcom/unity3d/a/a/a/k;->c:Ljava/lang/Enum;

    return-object v0
.end method

.method public c()[Ljava/lang/Object;
    .registers 2

    .line 33
    iget-object v0, p0, Lcom/unity3d/a/a/a/k;->b:[Ljava/lang/Object;

    return-object v0
.end method
