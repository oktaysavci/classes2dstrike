.class public interface abstract Lcom/unity3d/a/a/a/g;
.super Ljava/lang/Object;
.source "IScarRewardedAdListenerWrapper.java"
