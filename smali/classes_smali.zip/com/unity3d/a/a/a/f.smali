.class public interface abstract Lcom/unity3d/a/a/a/f;
.super Ljava/lang/Object;
.source "IScarInterstitialAdListenerWrapper.java"
