.class public interface abstract Lcom/unity3d/a/a/a/h;
.super Ljava/lang/Object;
.source "IUnityAdsError.java"
