.class public interface abstract Lcom/unity3d/a/a/a/a/b;
.super Ljava/lang/Object;
.source "IScarLoadListener.java"
