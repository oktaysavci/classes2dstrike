.class public Lcom/unity3d/a/a/b/a/e;
.super Ljava/lang/Object;
.source "ScarRewardedAdListener.java"


# instance fields
.field private a:Lcom/google/android/gms/ads/rewarded/RewardedAd;

.field private b:Lcom/unity3d/a/a/a/g;

.field private c:Lcom/unity3d/a/a/a/a/b;

.field private d:Lcom/google/android/gms/ads/rewarded/RewardedAdLoadCallback;

.field private e:Lcom/google/android/gms/ads/rewarded/RewardedAdCallback;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/ads/rewarded/RewardedAd;Lcom/unity3d/a/a/a/g;)V
    .registers 4

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    new-instance v0, Lcom/unity3d/a/a/b/a/e$1;

    invoke-direct {v0, p0}, Lcom/unity3d/a/a/b/a/e$1;-><init>(Lcom/unity3d/a/a/b/a/e;)V

    iput-object v0, p0, Lcom/unity3d/a/a/b/a/e;->d:Lcom/google/android/gms/ads/rewarded/RewardedAdLoadCallback;

    .line 37
    new-instance v0, Lcom/unity3d/a/a/b/a/e$2;

    invoke-direct {v0, p0}, Lcom/unity3d/a/a/b/a/e$2;-><init>(Lcom/unity3d/a/a/b/a/e;)V

    iput-object v0, p0, Lcom/unity3d/a/a/b/a/e;->e:Lcom/google/android/gms/ads/rewarded/RewardedAdCallback;

    .line 18
    iput-object p1, p0, Lcom/unity3d/a/a/b/a/e;->a:Lcom/google/android/gms/ads/rewarded/RewardedAd;

    .line 19
    iput-object p2, p0, Lcom/unity3d/a/a/b/a/e;->b:Lcom/unity3d/a/a/a/g;

    return-void
.end method


# virtual methods
.method public a()Lcom/google/android/gms/ads/rewarded/RewardedAdCallback;
    .registers 2

    .line 60
    iget-object v0, p0, Lcom/unity3d/a/a/b/a/e;->e:Lcom/google/android/gms/ads/rewarded/RewardedAdCallback;

    return-object v0
.end method

.method public a(Lcom/unity3d/a/a/a/a/b;)V
    .registers 2

    .line 66
    iput-object p1, p0, Lcom/unity3d/a/a/b/a/e;->c:Lcom/unity3d/a/a/a/a/b;

    return-void
.end method

.method public b()Lcom/google/android/gms/ads/rewarded/RewardedAdLoadCallback;
    .registers 2

    .line 63
    iget-object v0, p0, Lcom/unity3d/a/a/b/a/e;->d:Lcom/google/android/gms/ads/rewarded/RewardedAdLoadCallback;

    return-object v0
.end method
