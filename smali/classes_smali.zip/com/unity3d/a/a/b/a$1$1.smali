.class Lcom/unity3d/a/a/b/a$1$1;
.super Ljava/lang/Object;
.source "ScarAdapter.java"

# interfaces
.implements Lcom/unity3d/a/a/a/a/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/unity3d/a/a/b/a$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/unity3d/a/a/b/a$1;


# direct methods
.method constructor <init>(Lcom/unity3d/a/a/b/a$1;)V
    .registers 2

    .line 34
    iput-object p1, p0, Lcom/unity3d/a/a/b/a$1$1;->a:Lcom/unity3d/a/a/b/a$1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
