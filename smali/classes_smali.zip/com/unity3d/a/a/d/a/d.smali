.class public Lcom/unity3d/a/a/d/a/d;
.super Lcom/unity3d/a/a/d/a/b;
.source "ScarInterstitialAdListener.java"


# instance fields
.field private final b:Lcom/unity3d/a/a/d/a/c;

.field private final c:Lcom/unity3d/a/a/a/f;

.field private final d:Lcom/google/android/gms/ads/interstitial/InterstitialAdLoadCallback;

.field private final e:Lcom/google/android/gms/ads/FullScreenContentCallback;


# direct methods
.method public constructor <init>(Lcom/unity3d/a/a/a/f;Lcom/unity3d/a/a/d/a/c;)V
    .registers 4

    .line 16
    invoke-direct {p0}, Lcom/unity3d/a/a/d/a/b;-><init>()V

    .line 21
    new-instance v0, Lcom/unity3d/a/a/d/a/d$1;

    invoke-direct {v0, p0}, Lcom/unity3d/a/a/d/a/d$1;-><init>(Lcom/unity3d/a/a/d/a/d;)V

    iput-object v0, p0, Lcom/unity3d/a/a/d/a/d;->d:Lcom/google/android/gms/ads/interstitial/InterstitialAdLoadCallback;

    .line 40
    new-instance v0, Lcom/unity3d/a/a/d/a/d$2;

    invoke-direct {v0, p0}, Lcom/unity3d/a/a/d/a/d$2;-><init>(Lcom/unity3d/a/a/d/a/d;)V

    iput-object v0, p0, Lcom/unity3d/a/a/d/a/d;->e:Lcom/google/android/gms/ads/FullScreenContentCallback;

    .line 17
    iput-object p1, p0, Lcom/unity3d/a/a/d/a/d;->c:Lcom/unity3d/a/a/a/f;

    .line 18
    iput-object p2, p0, Lcom/unity3d/a/a/d/a/d;->b:Lcom/unity3d/a/a/d/a/c;

    return-void
.end method


# virtual methods
.method public a()Lcom/google/android/gms/ads/interstitial/InterstitialAdLoadCallback;
    .registers 2

    .line 67
    iget-object v0, p0, Lcom/unity3d/a/a/d/a/d;->d:Lcom/google/android/gms/ads/interstitial/InterstitialAdLoadCallback;

    return-object v0
.end method
