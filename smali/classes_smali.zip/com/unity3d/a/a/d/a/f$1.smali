.class Lcom/unity3d/a/a/d/a/f$1;
.super Lcom/google/android/gms/ads/rewarded/RewardedAdLoadCallback;
.source "ScarRewardedAdListener.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/unity3d/a/a/d/a/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/unity3d/a/a/d/a/f;


# direct methods
.method constructor <init>(Lcom/unity3d/a/a/d/a/f;)V
    .registers 2

    .line 24
    iput-object p1, p0, Lcom/unity3d/a/a/d/a/f$1;->a:Lcom/unity3d/a/a/d/a/f;

    invoke-direct {p0}, Lcom/google/android/gms/ads/rewarded/RewardedAdLoadCallback;-><init>()V

    return-void
.end method
