.class Lcom/unity3d/a/a/d/a/f$2;
.super Ljava/lang/Object;
.source "ScarRewardedAdListener.java"

# interfaces
.implements Lcom/google/android/gms/ads/OnUserEarnedRewardListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/unity3d/a/a/d/a/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/unity3d/a/a/d/a/f;


# direct methods
.method constructor <init>(Lcom/unity3d/a/a/d/a/f;)V
    .registers 2

    .line 43
    iput-object p1, p0, Lcom/unity3d/a/a/d/a/f$2;->a:Lcom/unity3d/a/a/d/a/f;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
