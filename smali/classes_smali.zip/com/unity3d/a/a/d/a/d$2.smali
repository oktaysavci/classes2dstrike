.class Lcom/unity3d/a/a/d/a/d$2;
.super Lcom/google/android/gms/ads/FullScreenContentCallback;
.source "ScarInterstitialAdListener.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/unity3d/a/a/d/a/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/unity3d/a/a/d/a/d;


# direct methods
.method constructor <init>(Lcom/unity3d/a/a/d/a/d;)V
    .registers 2

    .line 40
    iput-object p1, p0, Lcom/unity3d/a/a/d/a/d$2;->a:Lcom/unity3d/a/a/d/a/d;

    invoke-direct {p0}, Lcom/google/android/gms/ads/FullScreenContentCallback;-><init>()V

    return-void
.end method
