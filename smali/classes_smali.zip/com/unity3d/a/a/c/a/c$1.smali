.class Lcom/unity3d/a/a/c/a/c$1;
.super Lcom/google/android/gms/ads/AdListener;
.source "ScarInterstitialAdListener.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/unity3d/a/a/c/a/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/unity3d/a/a/c/a/c;


# direct methods
.method constructor <init>(Lcom/unity3d/a/a/c/a/c;)V
    .registers 2

    .line 20
    iput-object p1, p0, Lcom/unity3d/a/a/c/a/c$1;->a:Lcom/unity3d/a/a/c/a/c;

    invoke-direct {p0}, Lcom/google/android/gms/ads/AdListener;-><init>()V

    return-void
.end method
