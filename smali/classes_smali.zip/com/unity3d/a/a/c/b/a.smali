.class public Lcom/unity3d/a/a/c/b/a;
.super Lcom/google/android/gms/ads/query/QueryInfoGenerationCallback;
.source "QueryInfoCallback.java"


# instance fields
.field private a:Lcom/unity3d/a/a/a/a;

.field private b:Lcom/unity3d/a/a/c/b/b;


# direct methods
.method public constructor <init>(Lcom/unity3d/a/a/c/b/b;Lcom/unity3d/a/a/a/a;)V
    .registers 3

    .line 15
    invoke-direct {p0}, Lcom/google/android/gms/ads/query/QueryInfoGenerationCallback;-><init>()V

    .line 16
    iput-object p2, p0, Lcom/unity3d/a/a/c/b/a;->a:Lcom/unity3d/a/a/a/a;

    .line 17
    iput-object p1, p0, Lcom/unity3d/a/a/c/b/a;->b:Lcom/unity3d/a/a/c/b/b;

    return-void
.end method
